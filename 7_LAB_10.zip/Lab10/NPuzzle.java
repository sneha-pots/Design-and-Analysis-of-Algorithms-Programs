import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;

public class NPuzzle {
	
	public static int dimension;
	
	// Bottom, left, top, right
	int[] row = { 1, 0, -1, 0 };
	int[] col = { 0, -1, 0, 1 };
	
    // To calculate cost = number of non-blank tiles not in their goal position
	public int calculateCost(int[][] initial, int[][] goal) {
		int count = 0;
		int n = initial.length;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (initial[i][j] != 0 && initial[i][j] != goal[i][j]) {
					count++;
				}
			}
		}
		return count;
	}
	
	public void printMatrix(int[][] matrix) {
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix.length; j++) {
				System.out.print(matrix[i][j] + " ");
			}
			System.out.println("");
		}
	}
	
    // To check if (x, y) is a valid matrix cordinate
	public boolean isSafe(int x, int y) {
		return (x >= 0 && x < dimension && y >= 0 && y < dimension);
	}
	
    //print path from root node to destination node
	public void printPath(Node root) {
		if (root == null) {
			return;
		}
		printPath(root.parent);
		printMatrix(root.matrix);
		System.out.println();
	}
	
    //checks if given initial puzzle is solvable
	public boolean isSolvable(int[][] matrix) {
		int count = 0;
		List<Integer> array = new ArrayList<Integer>();
		
        //adding all matrix elements to arrayList
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix.length; j++) {
				array.add(matrix[i][j]);
			}
		}
		
        //converting arrayList to integer array
		Integer[] anotherArray = new Integer[array.size()];
		array.toArray(anotherArray);
		
		for (int i = 0; i < anotherArray.length - 1; i++) {
			for (int j = i + 1; j < anotherArray.length; j++) { 
				if (anotherArray[i] != 0 && anotherArray[j] != 0 && anotherArray[i] > anotherArray[j]) {
					count++;
				}
			}
		}
		// puzzle is solvable if count is even
		return count % 2 == 0;
	}
	
    // To solve the N-puzzle using branch and bound
	public void solve(int[][] initial, int[][] goal, int x, int y) {

        //Create a priority queue to store live nodes of state space tree
		PriorityQueue<Node> pq = new PriorityQueue<Node>(1000, (a, b) -> (a.cost + a.level) - (b.cost + b.level));
		
        // create a root node and calculate its cost
        Node root = new Node(initial, x, y, x, y, 0, null);
		root.cost = calculateCost(initial, goal);
		pq.add(root);  // Add root to list of live nodes;

		// Finds a live node with least cost, add its childrens to list of live nodes and then delete it from the list
		while (!pq.isEmpty()) {
			Node min = pq.poll();
            
            printMatrix(min.matrix);
			if (min.cost == 0) {
				printPath(min);
				return;
			}
			
            // do for each child of Node min (max 4 children for a node)
			for (int i = 0; i < 4; i++) {
	            if (isSafe(min.x + row[i], min.y + col[i])) {
	            	Node child = new Node(min.matrix, min.x, min.y, min.x + row[i], min.y + col[i], min.level + 1, min);
	            	child.cost = calculateCost(child.matrix, goal);
	            	pq.add(child);
	            }
	        }
		}
	}
	
	public static void main(String[] args) {

		if (args.length != 1){
			System.out.println("Incorrect arguments. Provide size of problem.");
			return;
		}
		
		if (Integer.parseInt(args[0]) == 3){
			int[][] initial = {{1,0},{3,2}};
        	int[][] goal = {{1,2}, {3,0}};
			dimension = 2;
			// Blank tile coordinates
			int x = 0;
        	int y = 1;

			NPuzzle puzzle = new NPuzzle();
			puzzle.solve(initial, goal, x, y);
		}
		else if (Integer.parseInt(args[0]) == 8){
			int[][] initial = {{1, 8, 2}, {4, 0, 3}, {7, 6, 5}};
        	int[][] goal = {{1, 2, 3}, {4, 5, 6}, {7, 8, 0}}; 
			dimension = 3;
			// Blank tile coordinates
			int x = 1;
        	int y = 1;

			NPuzzle puzzle = new NPuzzle();
			puzzle.solve(initial, goal, x, y);
		}
		else if (Integer.parseInt(args[0]) == 15){
			int[][] initial = {{1,2,3,4}, {5,6,7,8}, {9,10,11,0}, {13,14,15,12}};
        	int[][] goal = {{1,2,3,4}, {5,6,7,8}, {9,10,11,12}, {13,14,15,0}};
			dimension = 4;
			// Blank tile coordinates
			int x = 2;
        	int y = 3;

			NPuzzle puzzle = new NPuzzle();
			puzzle.solve(initial, goal, x, y);
		}
	
        /*
		if (puzzle.isSolvable(initial)) {
            System.out.println("Puzzle is solvable.");
			puzzle.solve(initial, goal, x, y);
		} 
		else {
			System.out.println("The given puzzle is impossible to solve");
		}  
        */  
        
	}
}

