DAA Lab Assignment 10

This project consists of four programs. 

(1) N-Queens Problem(NQueens.java): Given an N x N chessboard and N queens, place the n queens on the chessboard in non-attackable positions. Consider different values of N as 8, 12, 16 and 20 and store all the solutions in a file. 

To compile this program: javac NQueens.java
To run this program: java NQueens

Solution details:
- The solution to all chessboard sizes will be written to a text file named as nqueens_output.txt.
- The solutions are written in such a way that each solution is nested by square brackets, as there can be multiple solutions to each chessboard size. 
- Since we already know that there can only be one queen in each row and column, the solution vector is only one dimensional and tells us the row placement of each queen. 
- For example if a solution for a 8 x 8 matrix were [3, 5, 2, 8, 6, 4, 7, 1], this means that the first queens is to be placed in the 3rd column of the first row, the second queen is to be placed in the 5th column of the second row, and so on. 
- We can take the index of the array plus one to be the row, and the value of that item to be the column, or vice versa. 

Logic:
- We use backtracking algorithm to solve this problem. 
- We place the queens one by one in different columns, starting from the first (leftmost one).
- When we place a queen in a column, we check for clashes with other already placed queens. 
- In the current column, if we find a row for which there is no clash, we add this row and column as part of the solution and return true. 
- If we do not find such a row due to clashes, we backtrack and return false. 
- The way we do this is, for every tried row:	
	- If the queen can be safely placed in this position, we mark the row and column as part of the solution, and then check recursively is placing the queen here leads to a solution. 
	- If this recursion leads to a solution, we return ture. 
	- If it doesn't lead to a solution, we unmark that row and column, backtrack, and go back to the first step and continue to try other rows. 
- Lastly, if all the rows have been tried but there's no solution, we return false and trigger backtracking. 

- In the main function, we put a for loop as the problem statement requires us to print all solutions of board sizes 8, 12, 16 and 20. I put a for loop that increments by 4 from 8 to 20 to implement this. The function executes that many times and each time, the new value of n is passed to it. 
- The method called isSafe is a utility function that checks if a queen can be placed on the board in that particular row and column. Since this function is called when column queens are alerady placed in columns, we only need to check to the left side for attacking queens. 
- the for loop in this method checks the row on the left side. There are are two more for loops to check the board on the upper and lower diagnol on the left side. 
- The method solveNQUtil is a recursive utility function to solve the N Queens problem. The base case returns true if all the queens are placed. 
- Later the foor loops consider each column and try placing the queens in all rows one by one. (It checks if a queen can be placed on board [i][col] by calling the isSafe function.) 
- If the placement is possible, it makes the result true and the value of board [i][col] is set to 1. If placing the queen in that position doesn't lead to any solution, then the queen is removed from that position, and we backtrack. The value of board[i][col] is set to 0. 
- Lastly, the function nQueen solves the whole problem. It many uses solveNQUtil(), which returns false if no queens can be placed, and returns true and prints the placement if it's possible. 

(2) Sum of Subsets Problem(SumOfSubsets.c): Given n distinct positive numbers called weights, and a value m, write a program to find all the subsets of these n numbers whose sums are m, using backtracking. 

To compile this program: gcc SumOfSubsets.c
To run this program: ./a.out <command line arguments>

How to give input: 
The input is to be given through the command line. The first argument should be the value of m, that is the target weight to be acheived through the subsets. 
The next argument is the array of the value of the weights (the n numbers). 
Sample input: ./a.out 30 5 10 13 12 18 15 

How output is provided: 
The output gives a statement conveying the sum and weights the user has input. Then each solution subset is printed on a new line. 
Sample output:
The possible subsets, to make a target sum of 30 using the weights 5, 10, 12, 13, 15, 18, are as follows:
    5   10   15
    5   12   13
   12   18

Logic:
- In the main function, we first calculate the size of the array by using the number of command line arguments recieved. 
- We then read the command line arguments and assign them to the variable m, and then to the weights array. We use the atoi function to convert the arguments to integers. 
- We then put a sanity check to make sure none of the weights are negative values, and to ensure that m is greater than all the given weights. If either of these fails, an error message is displayed. 
- We then print the statement, using help of for loop to print values of arrays, and then call the generateSubsets function. 
- Since we are using backtracking here, we consider only subsets which satisfy the given constraint. That is, the sum of the subset should be exactly equal to the value of m or the target weight. 
- We use tree diagrams to design the backtracking algorithm. 
- We keep adding elements to the tree. As we go down the depth of the tree, if the added sum is satisfying the constraints, we keep generating child nodes. 
- When the constraints are not met, we stop generation of that sub tree and backtrack to previous nodes and branch out there to explore the nodes that havne't been expored yet. 
- The generateSubsets is a wrapper that prints subsets that sum to the target sum amount (m value). 
- We first sort the set using qsort function, and keep adding to the tree and checking the sum at each level. 
- We have a subset_sum function for this. In this, when the target suum is achieved, we print that subset using the printSubset function. 
- In the case that the constraint is not met, we exclude the pevious item and consider this next candidate. 
- We do this until all the possibilities are explored. 

(3) Graph Coloring Problem (graphColoring.java): Let G be a graph with n vertices. Write a program to assign colors to the vertices of G, using minimum number of colors, in such a way that no two adjacent vertices have the same color.

To compile this program: javac GraphColoring.java
To run this program: java GraphColoring <command line arguments>

How to give input: 
The input is given through command line arguments. The first argument is the value of n, which is the number of colors available. 
The next argument is the number of vertices our graph G has. 
The next arguments are to be an array, which is an adjacency matrix representation of the graph. The value of the graph[i][j] will be 1 if there is a direct edge from i to j, and it will be 0 if not. 
Sample input: java graphColoring 3 4 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 
This will produce a 2D array that looks like this     
	    { 0, 1, 0, 1 }
            { 1, 0, 1, 0 }
            { 0, 1, 0, 1 }
            { 1, 0, 1, 0 }
This input produces a graph like this 
	  (3)---(2)
           |     |
           |     |
           |     |
          (0)---(1)

How output is provided: An array color[V] that should have numbers from 1 to n. color[i] should represent the color assigned to the ith vertex. The code should also return false if the graph cannot be colored with m colors.
Sample output: Following are the assigned colors 
1 2 1 2

Logic: 
- In the main function, the arguments are taken through the command line. There are some sanity checks in place to ensure the correct input. 
- The isSafe function is a utility function to check if the current color assignment is safe for vetex v. 
- The graphColoringUtil method is a recursive utility function to solve the problem. In this, there is a base case, which checks if all the vertices are assigned a color. 
- We keep considering the vertex v and try different colors, then by calling the isSafe method, we check if the assignment is fine or not. We keep calling this method recursively to assign colors to rest of the vertices. 
- If assigned a color, doesn't lead to a solution, we remove it and try again. If no color can be assigned at all, we just return false. 
- The graphColoring function solves this problem using backtracking. It mainly uses the previously described utility function. It returns false if the n colors cannot be assigned, otherwise it returns true and prints the assignment of colors. 
- We also have a method that prints the solution which is called when a solution is found. 
- Essentialy, we assign colors one by one to different vertices, starting from vertex 0. Before we assign the color, we check for safety by considering already assigned colors to the adjacent vertcies, and see if they have the same colors of not. 
- If it doesn't violate any conditions, it will be part of the solution, otherwise we backtrack. 

(4) n-Puzzle: Develop programs for 3-Puzzle, 8-Puzzle and 15-Puzzle Problems

To compile this program: javac NPuzzle.java
To run this program: java NPuzzle <command line arguments>

Sample input/output:
int[][] initial = {{1,0},{3,2}};
int[][] goal = {{1,2}, {3,0}};

java NPuzzle 3
1 0 
3 2 

1 2 
3 0

1 0
3 2

1 2
3 0

Idea:
The search for an answer node from the state space tree for this problem can be speeded by using an “intelligent” ranking function, also called an approximate cost function to avoid searching in sub-trees that do not contain an answer node. It is similar to the backtracking technique but uses a BFS-like search.
There are basically three types of nodes involved in Branch and Bound:
1. Live node is a node that has been generated but whose children have not yet been generated. 
2. E-node is a live node whose children are currently being explored. In other words, an E-node is a node currently being expanded. 
3. Dead node is a generated node that is not to be expanded or explored any further. All children of a dead node have already been expanded.
Cost function: 
Each node X in the search tree is associated with a cost. The cost function is useful for determining the next E-node. The next E-node is the one with the least cost. The cost function is defined as:
(We assume that moving one tile in any direction will have a 1 unit cost)

   c(x) = f(x) + h(x) where
   f(x) is the length of the path from root to x 
        (the number of moves so far) and
   h(x) is the number of non-blank tiles not in 
        their goal position (the number of mis-
        -placed tiles). There are at least h(x) 
        moves to transform state x to a goal state


