public class Node {

    // stores the parent node of the current node
    public Node parent;

    // stores matrix
	public int[][] matrix;
	
	// Empty tile cordinates
	public int x, y;
	
	// Number of non-empty misplaced tiles
	public int cost;
	
	// The number of moves so far
	public int level;
	
    //constructor for new Node
	public Node(int[][] matrix, int x, int y, int newX, int newY, int level, Node parent) {
		this.parent = parent;
		this.matrix = new int[matrix.length][];
		for (int i = 0; i < matrix.length; i++) {
			this.matrix[i] = matrix[i].clone();
		}
		
		// Swap values in (X, Y) and (newX, newY) in the matrix
		this.matrix[x][y]       = this.matrix[x][y] + this.matrix[newX][newY];
		this.matrix[newX][newY] = this.matrix[x][y] - this.matrix[newX][newY];
		this.matrix[x][y]       = this.matrix[x][y] - this.matrix[newX][newY];
		
        //initial cost is infinity
		this.cost = Integer.MAX_VALUE;
		this.level = level;

        //new coordinates of empty tile
		this.x = newX; 
		this.y = newY;
	}
	
}