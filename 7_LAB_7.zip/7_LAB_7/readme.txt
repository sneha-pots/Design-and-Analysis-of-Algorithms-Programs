DAA Lab Assignment 7

Description:
	This assignment consists of 2 programs:

(1) program1.c - Single Source Shortest Path Problem

Input format:
• The user is prompted to enter the source node from the vertex set using scanf.

Output format:
•	Firstly, the vertex set and source vertex are displayed.
•	Then we display the shortest distance and path from the source vertex to all other vertices.

Note: The adjacency matrix for the graph has been coded into the program. It can be changed by changing it in the source code and editing the number of vertices V.

Logic used:
•	The sssp() function solves the single source shortest path problem for the given graph and source node.
•	We create the cost[][] matrix from the graph by replacing all zeroes with infinity. (Infinity is defined as 9999).
•	The distance[] array stores distances of each node from the source. We initialize it using the corresponding values from the cost matrix. For distance of source, it is set to 0.
•	The pred[] array stores the predecessor of each node. We initialize it with the source node.
•	The visited[] array keeps a track of whether a node has been visited. 0 indicates not visited, 1 indicates visited. It is initialized with 1 for source, 0 for the rest.
•	count variable keeps track of how many nodes have been visited. It is initialized with 1 (source visited).
•	We do the following in a loop while count < V – 1:
    1.	Find the node that has the minimum distance in distance[] and has not been visited yet. This node (nextnode) will be visited next.
    2.	Mark nextnode with 1 in visited[].
    3.	Next, we check if there is a better path to the unvisited nodes via this nextnode. For each unvisited node i, We check if (distance of nextnode from source + distance from nextnode to i < distance of i from source). If true, we update the distance of i and set the predecessor of i to be nextnode.
    4.	Increment count by 1. 
After this loop ends, all values are final.

•	We print out the distance of each node from source using distance[] array.
•	We print out the shortest path of each node using pred[] array.


(2)HuffmanCodeSolution.java - Huffman codes

Input instructions: 

javac HuffmanCodeSolution.java 
java HuffmanCode Solution

Logic used:

First we read the string from the input file and get the frequency of character. We store this in a map.
The buildTree method is called. We extract the two nodes with the least frequencies and create a new node which is equal to the sum of these two frequencies. 
We add this node back to the queue, and recursively repeat this process until all the nodes are a part of the tree. 
Once the tree is created, each character is assigned a code by traversing this tree. At each node, if the required node is the left child, we add 0 to the code. Otherwise, we add 1. We save these prefix codes in the setPrefixCode method. 
Now each character has a code, and we replace all the characters with the codes. 
Next, we have to decode this code to get the original data. The encoded string is traversed left if there's a 0 and right if there's a 1.

Output consists of character frequencies, character codes, encoded string and decoded string.
Output is printed out.
We have harcoded the input string. 


Built With:
C

Authors:
Shagufta Anjum (19XJ1A0568)
Sneha Potluri (19XJ1A0572)
Group 7
