DAA Lab Assignment 5

Description:
	This assignment consists of 4 programs:
	(1) program1.c
		To perform Strassen's matrix multiplication.	  	
	(2)program2.c
		To solve the Defective Chessboard problem.
    	(3)bonus1.java
        	To find the kth smallest number in an array in O(n) time.
    	(4)bonus2.c 
        	To find the median of 2n elements from two sorted arrays of size n in O(logn) time.

1. Strassen's multiplication 

(No command line arguments required.)

Logic used:
•	We prefer Strassen's multiplication over regular matrix multiplication because its time complexity is slightly lower. This is because it uses only 7 multiplications as compared to the regular 8, making it more efficient, especially for larger matrix sizes. 
•	We first define the size of the matrix (2D array) to be 1024. 
•	In the main function, we allocate memory for three such matrices (the two being multiplied, and the resultant).
•	Next, we fill the two matrices to be multiplied (A and B) with random values between 0 and 20 using the inbuilt rand() function. 
•	The timer is initiated using gettimeofday() function. Then the Strassen’s multiplication function (called multiply()) is run. Once complete, the timer is stopped. 
•	In the multiply function, the matrix is partitioned in 4 parts recursively (by passing in appropriate array pointers) until we get block sizes of 2x2. Then, we perform Strassen's multiplication on each of these blocks using the Strassen() function. 
•	We then add the submatrices together until we have our resultant matrix.
•	Strassen’s equations used:
M1=(A+C)×(E+F)
M2=(B+D)×(G+H)
M3=(A−D)×(E+H)
M4=A×(F−H)
M5=(C+D)×(E)
M6=(A+B)×(H)
M7=D×(G−E)
Result[0][0] = M2+M3−M6−M7
Result[0][1] = M4+M6
Result[1][0] = M5+M7
Result[1][1] = M1−M3−M4−M5

Built With:
C

2. Defective Chessboard:

How to provide input:
First argument: Chessboard size (Any number of the form 2^k)
Second argument: Defective piece row index
Third argument: Defective piece column index
Input sample: ./a.out 1 2048 258 890

Logic used:
•	We implement the chessboard in the form of a 2D array of size NxN (where N = 2^k). We allocate memory for the matrix.
•	We set the value of the defective piece to 0 (location provided by user). The remaining matrix is initialized with -1.
•	The timer is initiated using gettimeofday() function. Then the chessboard() function (to solve the defective piece problem) is run. Once complete, the timer is stopped. 
•	In the chessboard() function, we take a matrix and search for the location of the defective piece/occupied piece (where triomino is placed). We do this by finding the cell where value is not equal to -1.
•	Then, we determine the quadrant in which the defective/occupied piece lies. 
•	Accordingly, we place a triomino covering a cell from all the three other quadrants, using the triomino() function. 
•	We then recursively partition the chessboard into 4 quadrants and continue the same process on each part.
•	The triominos are numbered and the number increments each time a triomino is placed. When all non-defective cells are covered, the problem is solved.

Built With:
C

Bonus problems

3. Kth smallest element:

How to provide input:
First argument: n (size of array)
Second argument: k (kth element to be found)
javac bonus1 <array size> <k>
Input sample: javac bonus1 5 2

Logic used:
•	To get the time complexity of this program in linear time, we use the median of medians logic. 
•	First, the array is divide into sub arrays with 5 elements each. All sub arrays will have 5 elements, except possibly the last one which might have less than 5.
•	The median of each of these sub arrays is found in the median method and stored in a separte array (referred to as the median array).This median method is recursively called. The time complexity of the steps so far is O(n). 
•	Next, this method is called: medOfMed = kthSmallest(median[0..⌈n/5⌉-1], ⌈n/10⌉). This step takes O(n/5) time.  
•	Then, the partition method is called. This takes O(n) time. 
•	Finally, we compare the value of pos and the value of k and return it using a recursive function. The worst case scenario of the final recursive steps would still be less than O(n).
•	The time complexity of this program, even in the worst case scenario, is O(n), as mentioned after each step.

Built with:
Java

4. Median of 2 sorted arrays:

How to provide input:
First argument: size of array
./a.out <size of array>
Input sample: ./a.out 6
•	We use a divide and conquer approach to solve the problem in O(logn) time.
•	The size of the arrays is taken via command line. We create 2 arrays A and B of this size, and take user input using scanf to fill in the elements of these arrays in ascending sorted order.
•	We pass these arrays to the getMedian() function. If the array size is 1, the median is simply their average. If array size is 2, the median will be the average of the greatest element among A[0] and B[0] and the least element among A[1] and B[1].
•	Otherwise, we find the median of each array using the median() function.
•	If they are equal, we have found the median of the entire merged array.
•	Otherwise if median of A is greater, we run the getMedian() function on the second half of A and first half of B. If median of B is greater, we run the getMedian() function on the first half of A and second half of B.

Built With:
C


Authors:
Shagufta Anjum (19XJ1A0568)
Sneha Potluri (19XJ1A0572)
Group 7
