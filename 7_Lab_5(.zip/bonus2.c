#include <stdio.h>
#include <stdlib.h>

//Utility functions
int max(int x, int y)
{
    return x > y ? x : y;
}

int min(int x, int y)
{
    return x > y ? y : x;
}

//To find median of single array
double median(int arr[], int N)
{
    if (N % 2 == 0)
    {
        double temp = ((double)arr[N / 2] + (double)arr[N / 2 - 1]) / 2;
        return temp;
    }
    else
    {
        double temp = arr[N / 2];
        return temp;
    }
}

//To find median of two sorted arrays
double getMedian(int A[], int B[], int N)
{
    double m1; //median of A
    double m2; //median of B

    if (N == 1)
    {
        printf("Median is: %.1lf\n", ((double)A[0] + (double)B[0]) / 2);
        return (double)((A[0] + B[0]) / 2);
    }

    if (N == 2)
    {
        printf("Median is: %.1lf\n", ((double)(max(A[0], B[0])) + (double)(min(A[1], B[1]))) / 2);
        return (double)((max(A[0], B[0]) + min(A[1], B[1])) / 2);
    }

    m1 = median(A, N); //median of array A
    m2 = median(B, N); //median of array B

    // If medians are equal then return either one
    if (m1 == m2)
    {
        printf("Median is: %.1lf\n", (double)(m1));
        return m1;
    }

    // if m1 < m2 then median must exist in A[m1....] and B[....m2]
    if (m1 < m2)
        return getMedian(A + N / 2, B, N - (N / 2));

    // if m1 > m2 then median must exist in ar1[....m1] and ar2[m2...]
    if (m1 > m2)
        return getMedian(A, B + N / 2, N - (N / 2));
}

int main(int argc, char *argv[])
{

    if (argc != 2)
    {
        printf("Invalid input format.\n");
        return 1;
    }

    if (atoi(argv[1]) <= 0)
    {
        printf("Invalid array size.\n");
        return 1;
    }

    int N = atoi(argv[1]);
    int A[N], B[N];

    printf("Enter array 1 elements (in sorted order): \n");
    for (int i = 0; i < N; i++)
    {
        printf("Element %d: ", i + 1);
        scanf("%d", &A[i]);
    }

    printf("Enter array 2 elements (in sorted order): \n");
    for (int i = 0; i < N; i++)
    {
        printf("Element %d: ", i + 1);
        scanf("%d", &B[i]);
    }

    double median = getMedian(A, B, N);
}
