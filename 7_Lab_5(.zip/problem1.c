#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

#define N 512

//To add two matrices
void add(int size, int **C, int **X, int **Y, int rowC, int colC) //To add 2 matrices
{
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size; j++)
        {
            C[i + rowC][j + colC] = X[i][j] + Y[i][j];
        }
    }
}

int **strassen(int **A, int **B, int **C, int rowA, int colA, int rowB, int colB)
{
    int p1 = A[rowA][colA] * (B[rowB][colB + 1] - B[rowB + 1][colB + 1]);
    int p2 = (A[rowA][colA] + A[rowA][colA + 1]) * B[rowB + 1][colB + 1];
    int p3 = (A[rowA + 1][colA] + A[rowA + 1][colA + 1]) * B[rowB][colB];
    int p4 = A[rowA + 1][colA + 1] * (B[rowB + 1][colB] - B[rowB][colB]);
    int p5 = (A[rowA][colA] + A[rowA + 1][colA + 1]) * (B[rowB][colB] + B[rowB + 1][colB + 1]);
    int p6 = (A[rowA][colA + 1] - A[rowA + 1][colA + 1]) * (B[rowB + 1][colB] + B[rowB + 1][colB + 1]);
    int p7 = (A[rowA][colA] - A[rowA + 1][colA]) * (B[rowB][colB] + B[rowB][colB + 1]);

    C[0][0] = p5 + p4 - p2 + p6;
    C[0][1] = p1 + p2;
    C[1][0] = p3 + p4;
    C[1][1] = p1 + p5 - p3 - p7;

    return C;
}

//Matrix partitioning and adding
int **multiply(int **A, int **B, int rowA, int colA, int rowB, int colB, int size)
{
    int **C = (int **)malloc(size * sizeof(int *));
    for (int i = 0; i < size; i++)
        C[i] = (int *)malloc(size * sizeof(int));

    if (size == 2)
    {
        C = strassen(A, B, C, rowA, colA, rowB, colB);
    }
    else
    {
        int newsize = size / 2;

        // C11 = A11 * B11 + A12 * B21
        add(newsize, C, multiply(A, B, rowA, colA, rowB, colB, newsize),
            multiply(A, B, rowA, colA + newsize, rowB + newsize, colB, newsize),
            0, 0);

        // C12 = A11 * B12 + A12 * B22
        add(newsize, C, multiply(A, B, rowA, colA, rowB, colB + newsize, newsize),
            multiply(A, B, rowA, colA + newsize, rowB + newsize, colB + newsize, newsize),
            0, newsize);

        // C21 = A21 * B11 + A22 * B21
        add(newsize, C, multiply(A, B, rowA + newsize, colA, rowB, colB, newsize),
            multiply(A, B, rowA + newsize, colA + newsize, rowB + newsize, colB, newsize),
            newsize, 0);

        // C22 = A21 * B12 + A22 * B22
        add(newsize, C, multiply(A, B, rowA + newsize, colA, rowB, colB + newsize, newsize),
            multiply(A, B, rowA + newsize, colA + newsize, rowB + newsize, colB + newsize, newsize),
            newsize, newsize);
    }
    return C;
}

//Measuring time taken to run block multiplication
void time_taken(struct timeval start, struct timeval end)
{
    long seconds = (end.tv_sec - start.tv_sec);
    long micros = ((seconds * 1000000) + end.tv_usec) - (start.tv_usec);

    printf("Time taken: %li ms\n", micros);
}

//Some Optional functions

void print_matrix(int **m, int n)
{
    int i, j;
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            printf("%d\t", m[i][j]);
        }
        printf("\n");
    }
}

int main()
{
    int i, j, k;

    //Dynamically allocating 2D arrays as matrices
    int **A = (int **)malloc(N * sizeof(int *));
    int **B = (int **)malloc(N * sizeof(int *));
    int **res = (int **)malloc(N * sizeof(int *));
    for (i = 0; i < N; i++)
    {
        A[i] = (int *)malloc(N * sizeof(int));
        B[i] = (int *)malloc(N * sizeof(int));
        res[i] = (int *)malloc(N * sizeof(int));
    }

    //int N = 1024, NxN size matrices being multiplied

    //Adding random values to the matrices A and B
    int lower = 0;
    int upper = 20;
    srand(time(0));
    for (i = 0; i < N; i++)
    {
        for (j = 0; j < N; j++)
        {
            A[i][j] = (rand() % (upper - lower + 1)) + lower;
            B[i][j] = (rand() % (upper - lower + 1)) + lower;
        }
    }

    struct timeval start, end;

    //Running strassens matrix multiplication

    gettimeofday(&start, NULL); // start timer
    res = multiply(A, B, 0, 0, 0, 0, N);
    gettimeofday(&end, NULL); //end timer
    time_taken(start, end);

    //printf("Matrix A\n");
    //print_matrix(A, N);

    //printf("Matrix B\n");
    //print_matrix(B, N);

    //printf("Strassen multiply\n");
    //print_matrix(res, N);

    //Freeing up space
    for (i = 0; i < N; i++)
    {
        free(A[i]);
        free(B[i]);
        free(res[i]);
    }
    free(A);
    free(B);
    free(res);

    return 0;
}
