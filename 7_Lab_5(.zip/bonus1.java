//Median of medians method to find kth/ith smallest element using time complexity O(n)
import java.util.*;

class bonus1 
{
  
    static int findMedian (int arr[], int i, int n) 
    {
    
        if (i <= n)
        {
	        Arrays.sort (arr, i, n);	// sorting the array 
        }
        else
        {
	        Arrays.sort (arr, n, i);
        }
    
        return arr[n / 2];	// returning middle element 
    }
  
    static int kthSmallest (int arr[], int l, int r, int k) 
    {
        //ensuring k is smaller than n (total number of elements)
        if (k > 0 && k <= r - l + 1)
        {
	        int n = r - l + 1;// number of elements in arr[l..r] 
	        int i;
	        int[] median = new int[(n + 4) / 5];//array for medians
	        for (i = 0; i < n / 5; i++)
	        {
	            median[i] = findMedian (arr, l + i * 5, 5);
	        }
	
	    //for last group if it has less than 5 elements 
	    if (i * 5 < n)
	    {
	        median[i] = findMedian (arr, l + i * 5, n % 5);
	        i++;
	    }

	    //recursive call for median of medians
	    int medOfMed = (i == 1) ? median[i - 1] : kthSmallest (median, 0, i - 1, i / 2);
        int pos = partition (arr, l, r, medOfMed);
	
        if (pos - l == k - 1)
	    {
	        return arr[pos];
	    }
	    if (pos - l > k - 1)
	  	{
	        return kthSmallest (arr, l, pos - 1, k);
	    }
	
        return kthSmallest (arr, pos + 1, r, k - pos + l - 1);
    }
    return Integer.MAX_VALUE;
  }
  
    static int[] swap (int[]arr, int i, int j) 
    {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
        return arr;
    }
  
    static int partition (int arr[], int l, int r, int x) 
    {
        int i;
        for (i = l; i < r; i++)
        {
	        if (arr[i] == x)
	        {
            break;
            }
        }
    
    swap (arr, i, r);
    
    // Standard partition algorithm 
    i = l;
    for (int j = l; j <= r - 1; j++)
    {
	    if (arr[j] <= x)
	    {
	        swap (arr, i, j);
	        i++;
	    }
    }
    swap (arr, i, r);
    return i;
    }
 
    public static void main (String[]args) 
    {
        if (args.length != 2)
        {
	        System.out.println("Please enter the values of n and k.");
        }
        
        else
        {
            int n = Integer.parseInt (args[0]);
	        int k = Integer.parseInt (args[1]);
            
            if (k > n)
	        {
	            System.out.println("Value of k should not be greater than value of n.");
	        }
	        else
	        {
	            int min = 0, max = 100;
	            int arr[] = new int[n];
	            int x;
	            System.out.println("Your array is: ");
	    
	            //generating random values in array between 0 and 100
	            for (x = 0; x < n; x++)
	            {
		            int random_int = (int) (Math.random () * (max - min + 1) + min);
		            arr[x] = random_int;
		            System.out.print(arr[x] + "\t");
	            } 
 
                System.out.println ("\nThe kth smallest element (k=" + k +") is " + kthSmallest (arr, 0, n - 1, k) + ".");
            } 
        } 
    } 
} 
