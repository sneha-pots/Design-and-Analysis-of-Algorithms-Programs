#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

int count = 0;

//Places a triomino at the given coordinates
void triomino(int **matrix, int x1, int y1, int x2,
              int y2, int x3, int y3)
{
    count++;
    matrix[x1][y1] = count;
    matrix[x2][y2] = count;
    matrix[x3][y3] = count;
}

//Solves defective chessboard problem
int chessboard(int **matrix, int size, int row, int col)
{
    if (size == 1) //Base case: Single cell
        return 0;

    //Finding defective cell coordinates
    int def_row, def_col;

    for (int i = row; i < row + size; i++)
    {
        for (int j = col; j < col + size; j++)
        {
            if (matrix[i][j] != -1)
            {
                def_row = i, def_col = j;
            }
        }
    }

    // If defective cell is 1st quadrant
    if (def_row < row + size / 2 && def_col < col + size / 2)
        triomino(matrix, row + size / 2, col + (size / 2) - 1, row + size / 2,
                 col + size / 2, row + size / 2 - 1, col + size / 2);

    // If defective cell is in 2nd quadrant
    else if (def_row < row + size / 2 && def_col >= col + size / 2)
        triomino(matrix, row + size / 2, col + (size / 2) - 1, row + size / 2,
                 col + size / 2, row + (size / 2) - 1, col + (size / 2) - 1);

    // If defective cell is in 3rd quadrant
    else if (def_row >= row + size / 2 && def_col < col + size / 2)
        triomino(matrix, row + size / 2, col + size / 2, row + (size / 2) - 1,
                 col + size / 2, row + (size / 2) - 1, col + (size / 2) - 1);

    // If defective cell is in 4th quadrant
    else if (def_row >= row + size / 2 && def_col >= col + size / 2)
        triomino(matrix, row + size / 2, col + (size / 2) - 1, row + (size / 2) - 1,
                 col + size / 2, row + (size / 2) - 1, col + (size / 2) - 1);

    //Dividing board into 4 quadrants
    chessboard(matrix, size / 2, row, col);                       //quad 1
    chessboard(matrix, size / 2, row, col + size / 2);            //quad 2
    chessboard(matrix, size / 2, row + size / 2, col);            //quad 3
    chessboard(matrix, size / 2, row + size / 2, col + size / 2); //quad 4

    return 0;
}

//Creates a chessboard using dynamic memeory allocation
int **create_matrix(int size)
{
    int **matrix = (int **)malloc(size * sizeof(int *));
    for (int i = 0; i < size; i++)
    {
        matrix[i] = (int *)malloc(size * sizeof(int));
    }
    return matrix;
}

//Frees space allocated for the board
void free_matrix(int **matrix, int size)
{
    for (int i = 0; i < size; i++)
    {
        free(matrix[i]);
    }
    free(matrix);
}

//Prints chessbaord
void print_matrix(int **matrix, int size)
{
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size; j++)
            printf("%d\t", matrix[i][j]);
        printf("\n");
    }
}

//Initializing chessboard with -1
void init_matrix(int **matrix, int size)
{
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size; j++)
            matrix[i][j] = -1;
    }
}

//Measuring time taken to run chessboard fn
void time_taken(struct timeval start, struct timeval end, int size)
{
    long seconds = (end.tv_sec - start.tv_sec);
    long micros = ((seconds * 1000000) + end.tv_usec) - (start.tv_usec);

    printf("Time taken for chessboard of size %d: %li microseconds\n", size, micros);
}

int main(int argc, char *argv[])
{
    if (argc != 4)
    {
        printf("Invalid input format.\n");
        return 1;
    }

    // User inputs
    int size = atoi(argv[1]);    //Size of chessboard
    int def_row = atoi(argv[2]); //Row of defective piece
    int def_col = atoi(argv[3]); //Column of defective piece

    if (def_row < 0 || def_row > size - 1 || def_col < 0 || def_col > size - 1)
    {
        printf("Invalid defective piece location.\n");
        return 1;
    }

    struct timeval start, end;

    int **A = create_matrix(size); //Creating board
    init_matrix(A, size);          //Initializing with -1

    // Defective piece is given value 0
    A[def_row][def_col] = 0;

    gettimeofday(&start, NULL); // start timer

    chessboard(A, size, 0, 0); //PLacing triominos

    gettimeofday(&end, NULL); //end timer

    time_taken(start, end, size); //Calculate time taken

    free_matrix(A, size); //Freeing matrix space

    return 0;
}