#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

struct student
{
	char id[20];
	char name[50];
	int group;
	int index;
};

void swap(struct student *x, struct student *y)
{
	struct student temp = *x;
	*x = *y;
	*y = temp;
}

void selectionSort(struct student arr[], int n, int opt, char search[])
{
	int i, j, min;
	for (i = 0; i < n - 1; i++)
	{
		min = i;
		for (j = i + 1; j < n; j++)
		{
			if (opt == 1)
			{
				if (strcmp(arr[j].id, arr[min].id) < 0)
					min = j;
			}
			else if (opt == 2)
			{
				if (strcmp(arr[j].name, arr[min].name) < 0)
					min = j;
			}
			else if (opt == 3)
			{
				if (arr[j].group < arr[min].group)
					min = j;
			}
		}
		swap(&arr[min], &arr[i]);
	}
}

int count = 0;
int binarySearch(struct student arr[], int low, int high, char search[], int opt)
{
	//Opening output file
	FILE *output;
	output = fopen("DAALab_output1.txt", "a");
	if (output == NULL)
	{
		printf("Error opening file\n");
		return 1;
	}

	int result, mid;
	int found = 0;

	if (high >= low)
	{
		mid = low + (high - low) / 2; //Finding middle value

		if (opt == 1)
			result = strcmp(arr[mid].id, search); //Search by roll number
		else if (opt == 2)
			result = strcmp(arr[mid].name, search); //Search by name
		else if (opt == 3)
		{
			if (arr[mid].group == atoi(search)) //Search by group
				result = 0;
			else if (arr[mid].group < atoi(search))
				result = -1;
			else
				result = 1;
		}

		//Element found
		if (result == 0)
		{
			count++;
			fprintf(output, "%s %s %i\n", arr[mid].id, arr[mid].name, arr[mid].group);
			fprintf(output, "Index: %d\n", arr[mid].index);

			//Continuing search for more elements
			binarySearch(arr, mid + 1, high, search, opt);
			binarySearch(arr, low, mid - 1, search, opt);
		}

		//Searching in right half
		else if (result < 0)
		{
			binarySearch(arr, mid + 1, high, search, opt);
		}

		//Searching in left half
		else if (result > 0)
		{
			binarySearch(arr, low, mid - 1, search, opt);
		}
	}
}

int main(int argc, char *argv[])
{

	if (argc == 3)
	{
		//Option for searching criteria
		int opt = atoi(argv[1]);

		if (opt == 1 || opt == 2 || opt == 3)
		{
			//Which element to search for
			char search[30];
			strcpy(search, argv[2]);

			int i = 0;

			//Reading input file
			FILE *fp;
			fp = fopen("DAALab_input1.txt", "r");
			if (fp == NULL)
			{
				printf("Error opening file\n");
				return 1;
			}
			//Counting number of lines in file
			int total = 0;
			char c;
			while ((c = fgetc(fp)) != EOF)
			{
				if (c = '\0' || c == '\n')
					total++;
			}

			rewind(fp);
			total = total + 1;
			struct student slist[total];

			//Assigning indices
			while (fscanf(fp, "%s %s %i", slist[i].id, slist[i].name, &(slist[i].group)) != EOF)
			{
				slist[i].index = i;
				i++;
			}

			//Clearing output file
			fp = fopen("DAALab_output1.txt", "w");
			if (fp == NULL)
			{
				printf("Error opening file\n");
				return 1;
			}

			//Sorting
			selectionSort(slist, total, opt, search);

			//Running binary search
			binarySearch(slist, 0, total - 1, search, opt);

			if (count == 0)
				fprintf(fp, "Element not found.\n");
			else
			{
				fseek(fp, 0, SEEK_END);
				fprintf(fp, "No. of records found: %d\n\n", count);
			}

			fclose(fp);
			return 0;
		}
		else
		{
			printf("\nInvalid input.");
			return 1;
		}
	}
	else
	{
		printf("\nInvalid input.");
		return 1;
	}
}
