DAA Lab Assignment 3

Description:
	This project consists of 3 programs to search a file of student records for the required element based on: 
	(1) program1.c
		To search the file using Linear Search (multiple occurences).	  	
	(2)program2.c
		To search the file using Binary Search (multiple occurences).
	(3) program3.c
		To search the file using Fibonacci Search (single occurence).

	Users can opt to search for a roll number, name or group number.
	
Note: Output file may need to be reloaded to see changes.

How to provide input:
First argument: 1 (search by roll number), 2 (search by name), or 3 (search by group number)
Second argument: Element to be searched for
Input sample: ./a.out 1 19XJ1A0572
		or ./a.out 2 SNEHA
		or ./a.out 3 7

General working:	
- The data from the input file is stored in an array of structures.
- The output is printed to file DAALab_output1.txt. It will print all the details (hall ticket number, name and group number) of the element and the index at which it is found.
- If there is more than one match, details and indices of all matches are printed.
- Finally, the number of records found will be printed. 
- If the element doesn't exist, a relevant message is printed (This works because if the count variable is still at 0, the program goes into that if condition).


Algorithm logic used:

- Linear search: (for multiple occurrences)
o	The element which is to be searched for is saved as a string. For convenience, we have taken group numbers as string as well.
o	In a for loop, each element of the given structure is compared with the search element. We keep iterating through the array. Whenever the two match, it's printed into the file. 
o	The iteration continues until the end of the array, to ensure that multiple matches are printed as well. 
o	An integer called count is initialized to 0. If the program enters the if loop, the count value is incremented. At the end, if the count value is 0, it means that the element never entered the if loop, so the element was not found. A message saying "The item you are looking for is not present." will be printed. 
o	If count value is not 0, the program will enter the else loop, and the number of records printed will be shown using the count value. 
o	The index of the element found is also printed under the details of the student, using the i value from the for loop. 	

 -Binary search: (for multiple occurrences)
o	The element to be searched for is saved as a string. 
o	We have used selection sort technique to sort the list into ascending order, depending on which parameter the user would like to search by.
o	Once sorted, we run the binary search function, and all the necessary elements are passed to it. 
o	Binary search uses the divide and conquer method. It divides the array into two parts by using the middle value which is being calculated. 
o	If the search element matches the middle element, it is found. If not, we check if the value of the middle element is greater than or less than the value of the search element. If it's greater than, the second half of the array is now passed again into the function as the new array and process is recursively continued until the search element is found. Similarly, if it's less than the middle element, the first half of the array is passed. 
o	If an element is found, it is printed to the output file with its index. Then, we run binary search on the left and right halves of the array to continue searching for more matches.
o	Each match is appended to the output file.
o	If the user chooses to search based on group number, the search element is converted to an integer using the atoi() function, so that it can be easily compared against the group numbers, which we have taken to be integers. 

- Fibonacci Search: (for single occurrence)
o	First, we sort our array using selection sort depending on the parameter chosen by user.
o	We find the smallest Fibonacci Number greater than or equal to the size of the array. Let this number be fib [nth Fibonacci Number]. The two Fibonacci numbers preceding it are fib1 [(n-1)th Fibonacci Number] and fib2 [(n-2)th Fibonacci Number].
o	The offset variable (keeps getting updated) indicates the range of the array that has been eliminated, starting from the front. 
o	While the array has elements, we compare x (element to be searched for) with the last element of the range covered by fib2.
o	If x matches, we print the details of the students to the output file and return the index.
o	Else If x is less than the element, we move the three variables two Fibonacci numbers down by changing their values. This basically eliminates about two-third of the remaining array from the back end.
o	Else If x is greater than the element, move the three variables one Fibonacci number down. Then, we reset offset to index. This eliminates about one-third of the remaining array from the front.
o	There is a chance that a single element is left to be compared at the end. So, we check if fib1 is 1. If so, we compare x with that remaining element and if it matches, we print it to the output file & return its index.


Built With:
C

Authors:
Sneha Potluri (19XJ1A0572)
Shagufta Anjum (19XJ1A0568)
Group 7
