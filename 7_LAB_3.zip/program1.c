#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

struct student
{
	char id[20];
	char name[50];
	char group[3];
};

void linearSearch(struct student arr[], int total, char search[], int opt)
{

	FILE *output;
	output = fopen("DAALab_output1.txt", "w");
	int i, result, count = 0;

	//search by id
	if (opt == 1)
	{
		for (i = 0; i < total; i++)
		{
			result = strcmp(arr[i].id, search);
			if (result == 0)
			{
				fprintf(output, "%s %s %s\n", arr[i].id,
						arr[i].name, arr[i].group);
				fprintf(output, "Index: %d\n", i);
				count++;
			}
		}
		if (count == 0)
		{
			fprintf(output, "Item not found.\n");
		}
		else
		{
			fprintf(output, "\nNumber of records found: %d\n", count);
		}
	}

	//search by name
	if (opt == 2)
	{
		for (i = 0; i < total; i++)
		{
			result = strcmp(arr[i].name, search);
			if (result == 0)
			{
				fprintf(output, "%s %s %s\n", arr[i].id,
						arr[i].name, arr[i].group);
				fprintf(output, "Index: %d\n", i);
				count++;
			}
		}
		if (count == 0)
		{
			fprintf(output, "Item not found.\n");
		}
		else
		{
			fprintf(output, "\nNumber of records found: %d\n", count);
		}
	}

	//search by group
	if (opt == 3)
	{
		for (i = 0; i < total; i++)
		{
			result = strcmp(arr[i].group, search);
			if (result == 0)
			{
				fprintf(output, "%s %s %s\n", arr[i].id,
						arr[i].name, arr[i].group);
				fprintf(output, "Index: %d\n", i);
				count++;
			}
		}
		if (count == 0)
		{
			fprintf(output, "Item not found.\n");
		}
		else
		{
			fprintf(output, "\nNumber of records found: %d\n", count);
		}
	}

	fclose(output);
}

int main(int argc, char *argv[])
{

	if (argc == 3)
	{
		//Option for searching criteria
		int opt = atoi(argv[1]);

		if (opt == 1 || opt == 2 || opt == 3)
		{
			//which element to search for
			char search[30];
			strcpy(search, argv[2]);

			int i = 0;

			FILE *input;
			input = fopen("DAALab_input1.txt", "r");
			if (input == NULL)
			{
				printf("Error opening file\n");
			}

			//Counting number of lines in file
			int total = 0;
			char c;
			while ((c = fgetc(input)) != EOF)
			{
				if (c = '\0' || c == '\n')
					total++;
			}
			rewind(input);
			total = total + 1;

			//Creating student struct array
			struct student slist[total];

			//Reading from input file
			while (fscanf(input, "%s %s %s", slist[i].id, slist[i].name, slist[i].group) != EOF)
			{
				i++;
			}

			//Running linear search algorithm
			linearSearch(slist, total, search, opt);

			fclose(input);
			return 0;
		}
		else
		{
			printf("\nInvalid input.");
			return 1;
		}
	}
	else
	{
		printf("\nInvalid input.");
		return 1;
	}
}
