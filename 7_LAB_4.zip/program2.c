#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

#define N 1024

//Function declarations
void print_matrix(int **m, int n);
int **reg_multiply(int **A, int **B, int **result, int n);
void add(int size, int **C, int **X, int **Y, int rowC, int colC);
int **multiply(int **A, int **B, int rowA, int colA, int rowB, int colB, int size, int block_size);
void time_taken(struct timeval start, struct timeval end, int block_size);

int main()
{
    int i, j, k;

    //Dynamically allocating 2D arrays as matrices
    int **A = (int **)malloc(N * sizeof(int *));
    int **B = (int **)malloc(N * sizeof(int *));
    int **res = (int **)malloc(N * sizeof(int *));
    for (i = 0; i < N; i++)
    {
        A[i] = (int *)malloc(N * sizeof(int));
        B[i] = (int *)malloc(N * sizeof(int));
        res[i] = (int *)malloc(N * sizeof(int));
    }

    //int N = 1024, NxN size matrices being multiplied

    //Adding random values to the matrices A and B
    int lower = 0;
    int upper = 20;
    srand(time(0));
    for (i = 0; i < N; i++)
    {
        for (j = 0; j < N; j++)
        {
            A[i][j] = (rand() % (upper - lower + 1)) + lower;
            B[i][j] = (rand() % (upper - lower + 1)) + lower;
        }
    }

    int block_size;
    struct timeval start, end;

    //Running block multiplication for various block sizes

    block_size = 4;
    gettimeofday(&start, NULL); // start timer
    res = multiply(A, B, 0, 0, 0, 0, N, block_size);
    gettimeofday(&end, NULL); //end timer
    time_taken(start, end, block_size);

    block_size = 8;
    gettimeofday(&start, NULL); // start timer
    res = multiply(A, B, 0, 0, 0, 0, N, block_size);
    gettimeofday(&end, NULL); //end timer
    time_taken(start, end, block_size);

    block_size = 16;
    gettimeofday(&start, NULL); // start timer
    res = multiply(A, B, 0, 0, 0, 0, N, block_size);
    gettimeofday(&end, NULL); //end timer
    time_taken(start, end, block_size);

    block_size = 32;
    gettimeofday(&start, NULL); // start timer
    res = multiply(A, B, 0, 0, 0, 0, N, block_size);
    gettimeofday(&end, NULL); //end timer
    time_taken(start, end, block_size);

    block_size = 64;
    gettimeofday(&start, NULL); // start timer
    res = multiply(A, B, 0, 0, 0, 0, N, block_size);
    gettimeofday(&end, NULL); //end timer
    time_taken(start, end, block_size);

    /**
    printf("Matrix A\n");
    print_matrix(A, N);

    printf("Matrix B\n");
    print_matrix(B, N);

    printf("Block multiply\n");
    print_matrix(res, N);

    
//Regular matrix multiplication (for cross-checking)
    res = reg_multiply(A, B, res, N);
    printf("Regular multiply\n");
    print_matrix(res, N);

**/

    //Freeing up space
    for (i = 0; i < N; i++)
    {
        free(A[i]);
        free(B[i]);
        free(res[i]);
    }
    free(A);
    free(B);
    free(res);

    return 0;
}

//To add two matrices
void add(int size, int **C, int **X, int **Y, int rowC, int colC) //To add 2 matrices
{
    int n = size;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            C[i + rowC][j + colC] = X[i][j] + Y[i][j];
        }
    }
}

//Block matrix multiplication
int **multiply(int **A, int **B, int rowA, int colA, int rowB, int colB, int size, int block_size)
{
    int **C = (int **)malloc(size * sizeof(int *));
    for (int i = 0; i < size; i++)
        C[i] = (int *)malloc(size * sizeof(int));

    if (size == block_size)
    {
        for (int i = 0; i < block_size; i++)
        {
            for (int j = 0; j < block_size; j++)
            {
                C[i][j] = 0;
                for (int k = 0; k < block_size; k++)
                    C[i][j] += A[i + rowA][k + colA] * B[k + rowB][j + colB];
            }
        }
    }
    else
    {
        int newsize = size / 2;

        // C11 = A11 * B11 + A12 * B21
        add(newsize, C, multiply(A, B, rowA, colA, rowB, colB, newsize, block_size),
            multiply(A, B, rowA, colA + newsize, rowB + newsize, colB, newsize, block_size),
            0, 0);

        // C12 = A11 * B12 + A12 * B22
        add(newsize, C, multiply(A, B, rowA, colA, rowB, colB + newsize, newsize, block_size),
            multiply(A, B, rowA, colA + newsize, rowB + newsize, colB + newsize, newsize, block_size),
            0, newsize);

        // C21 = A21 * B11 + A22 * B21
        add(newsize, C, multiply(A, B, rowA + newsize, colA, rowB, colB, newsize, block_size),
            multiply(A, B, rowA + newsize, colA + newsize, rowB + newsize, colB, newsize, block_size),
            newsize, 0);

        // C22 = A21 * B12 + A22 * B22
        add(newsize, C, multiply(A, B, rowA + newsize, colA, rowB, colB + newsize, newsize, block_size),
            multiply(A, B, rowA + newsize, colA + newsize, rowB + newsize, colB + newsize, newsize, block_size),
            newsize, newsize);
    }
    return C;
}

//Measuring time taken to run block multiplication
void time_taken(struct timeval start, struct timeval end, int block_size)
{
    long seconds = (end.tv_sec - start.tv_sec);
    long micros = ((seconds * 1000000) + end.tv_usec) - (start.tv_usec);

    printf("Time taken for block size %d: %li ms\n", block_size, micros);
}

//Optional functions

void print_matrix(int **m, int n)
{
    int i, j;
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            printf("%d\t", m[i][j]);
        }
        printf("\n");
    }
}

int **reg_multiply(int **A, int **B, int **result, int n) //regular matrix multiplication
{
    int i, j, k;
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            result[i][j] = 0;
            for (k = 0; k < n; k++)
                result[i][j] += A[i][k] * B[k][j];
        }
    }
    return result;
}
