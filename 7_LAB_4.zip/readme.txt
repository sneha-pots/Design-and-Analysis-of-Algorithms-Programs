DAA Lab Assignment 4

Description:
    This project consists of two programs. The first sorts the given file of student records using a binary tree sorting algorithms. The second performs block matrix multiplication and analyzes the results. 

program1.c
    To sort the records in ascending order based on one of three parameters - Roll number, Name or Group number - which is to be provided by the user via command line arguments. Output is written to the DAALab_output1.txt file.

    Input argument: 1 (for roll number) or 2 (for name) or 3 (for group)
    Input sample: ./a.out 1 
		or ./a.out 2
		or ./a.out 3

Note: Output file may need to be reloaded to see changes.

Logic used:
- A structure is created with 5 elements. A pointer to the leftchild and rightchild, and the three elements in the input file (roll number, name, and group number).
- In the main function, the opt argument provided by the user is read. 
- The file is opened, read, and the data is stored in the strucutre. 
- Next, the number of lines in the input file is calculated to determine the value of total. 
- If the opt value is not 1,2, or 3, or the input file is empty, a message saying "Invalid Input" or "Error opening file" will be displayed. 
- Next, the tree node is created and memory is allocated for the root node using the first elements (0th position) of the structure. 
- Now, in a for loop, memory is allocated again, for each element. Here, an insert function is called. 
- The insert function checks (based on opt paramter) and compares the value of the current element (determined by i value from for loop) to the value of the root. 
  If it's less than the root, it goes to the left of the tree. If it's greater than or equal to the value of the root, it goes to the right of the tree. 
  Now, if the left/right children have more children, we must compare this value with those as well, to determine its exact position. 
  However, if the left/right children is a leaf, and it doesn't have any more children, we can insert the element there. We check this by seeing if the value of the pointer to the left/right child is NULL. If it's NULL, the element is inserted there. Else, the insert function is called again, recursively.
  This function is called recursively until all the elements are traversed through and our binary search tree is created. 
- Next, the inorder function is called. Here, the output file is opened, and the sorted data is printed into the output file itself.  

program2.c 
    To perform block matrix multiplication on two matrices of size 1024 x 1024 using block sizes of 4, 8, 16, 32 and 64. The time taken for each of these runs is calculated and analyzed.

Input sample: ./a.out 
(No arguments required)

Note: Due to large matrix size, program may take a while to run.

Logic used:
•	Two matrices (implemented as 2 dimensional arrays) named A and B of size 1024 x 1024 are created and allocated with memory using malloc.
•	The matrices are filled with random values ranging from 0 to 20.
•	We create the multiply() function to perform the block multiplication. In this recursive function, we first create the resultant matrix C. 
•	We call this function for various block sizes (4, 8, 16, 32, 64).
•	The large arrays of size 1024 are divided into 4 sub-matrices recursively until we reach the required block size.
•	Then, the sub-matrices of that block size are multiplied using regular matrix multiplication (iterative approach). The result is stored in C.
•	All the resultant matrices are then added together in an orderly manner to form the final resultant matrix. (Using add() function)
•	We use the gettimeofday() function to calculate the time taken to run the block multiply function for different block sizes. The time_taken() function calculates and prints out the runtime in microseconds.
•	For each block size, we make 5 runs and calculate the average runtime. This data is plotted in graphs. We notice that as the block size decreases, the runtime increases.
•	Lastly, we free the memory allocated using free().
Formulas used to partition and add submatrices: 
C11 = A11 * B11 + A12 * B21
C12 = A11 * B12 + A12 * B22
C21 = A21 * B11 + A22 * B21
C22 = A21 * B12 + A22 * B22

Built With:
C

Authors:
Shagufta Anjum (19XJ1A0568)
Sneha Potluri (19XJ1A0572)
Group 7

