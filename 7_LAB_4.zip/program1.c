#include<stdio.h>
#include<string.h>
#include<stdlib.h>

struct treenode
{
    struct treenode *leftchild;
    char id[20];
    char name[50];
    int group;
    struct treenode *rightchild;
};

void insert (struct treenode *, struct treenode *, int opt);
void inorder (struct treenode *, FILE *output);

int
main (int argc, char *argv[])
{
	if (argc!=2)
	{
		printf ("Invalid Input");
		return 1;
	}

int opt = atoi(argv[1]);  //Option for sorting parameter

   if (opt>3 || opt<1)
   {
       printf ("Invalid Input");
       return 1;
   }
   
   //Opening input file
    FILE *fp;
    fp = fopen("DAALab_input1.txt", "r");
    if (fp == NULL)
    {
        printf("Error opening file\n");
        return 1;
    }

    //Counting number of lines in file
	int total = 0;
	char c;
	while ((c = fgetc(fp)) != EOF)
	{
		if (c == '\0' || c == '\n')
		total++;
	}
	rewind(fp);
    
    struct treenode slist[total];

  //Reading from input file
           int i = 0;
            while (fscanf(fp, "%s %s %i", slist[i].id, slist[i].name, &(slist[i].group)) != EOF)
            {
                i++;
            }

    struct treenode *tree;
    tree = NULL;

    //making root
    tree = malloc (sizeof (struct treenode));
    tree->leftchild = NULL;
    strcpy (tree->id, slist[0].id);
    strcpy (tree->name, slist[0].name);
    tree->group = slist[0].group;
    tree->rightchild = NULL;
    
    struct treenode *temp;
    
    for (i = 1; i < total; i++)
    {
        temp = malloc (sizeof (struct treenode));
        temp->leftchild = NULL;
        strcpy (temp->id,slist[i].id);
        strcpy (temp->name,slist[i].name);
        temp->group = slist[i].group;
        temp->rightchild=NULL;
        
        insert (tree, temp, opt);
    }

 FILE *output;
	output = fopen("DAALab_output1.txt", "w");

	if (output == NULL)
	{
		printf ("Error opening file\n");
	}
    inorder (tree, output);
}

void
insert (struct treenode *tree, struct treenode *slist, int opt)
{
    if (opt == 1)
    {
        if ((strcmp (slist->id, tree->id)) < 0)
	    {
	        if (tree->leftchild == NULL)
	        {
	            tree->leftchild = slist;
	        }
	        else
	        {
	            insert (tree->leftchild, slist, opt);
	        }
	    }
        else
	    {
	        if (tree->rightchild == NULL)
	        {
	            tree->rightchild = slist;
	        }
            else
	        {
	            insert (tree->rightchild, slist, opt);
	        }
	    }
    }

    if (opt == 2)
    {
        if (strcmp (slist->name, tree->name) < 0)
	    {
	        if (tree->leftchild == NULL)
	        {
	            tree->leftchild = slist;
	        }
	        else
	        {
	            insert (tree->leftchild, slist, opt);
	        }
	    }
        else
	    {
	        if (tree->rightchild == NULL)
	        {
	            tree->rightchild = slist;
	        }
            else
	        {
	            insert (tree->rightchild, slist, opt);
	        }
	    }
    }

    if (opt == 3)
    {
        if (slist->group < tree->group)
	    {
	        if (tree->leftchild == NULL)
	        {
	            tree->leftchild = slist;
	        }
	        else
	        {
	            insert (tree->leftchild, slist, opt);
	        }
	    }
        else
	    {
	        if (tree->rightchild == NULL)
	        {
	            tree->rightchild = slist;
	        }
            else
	        {
	            insert (tree->rightchild, slist, opt);
	        }
	    }
    }
}

void
inorder (struct treenode *tree, FILE *output)
{
    	
  if (tree != NULL)
    {
      inorder (tree->leftchild, output);
      fprintf (output, "%s %s %d\n", tree->id, tree->name, tree->group);
      inorder (tree->rightchild, output);
    }

}