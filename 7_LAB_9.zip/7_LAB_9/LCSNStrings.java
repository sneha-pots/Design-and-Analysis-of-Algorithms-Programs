// Bonus: Finding LCS of n strings 

import java.io.*;
import java.util.*;
 
class LCSNStrings {
 
    //method to find LCS from string array 
    //return type: string 
    public static String findstem(String arr[])
    {
        int n = arr.length; //number of strings (size of array)
 
        //taking first word from array as reference
        String s = arr[0];
        int len = s.length();
 
        String res = ""; //LCS
 
        for (int i = 0; i < len; i++) 
        {
            for (int j = i + 1; j <= len; j++) 
            {
 
                // generating all possible substrings from reference string (first word)
                String stem = s.substring(i, j);
                int k = 1;
                for (k = 1; k < n; k++)
 
                    //checking if the generated stem is common to all arguments
                    if (!arr[k].contains(stem))
                    {
                        break;
                    }
                    
                if (k == n && res.length() < stem.length())
                {
                    res = stem;
                }
            }
        }
 
        return res;
    }
 
    public static void main(String args[])
    {
        //testing command line arguments
        /* 
        for(int i = 0; i<args.length; i++) 
        {
        System.out.println(args[i]);
        }
        */
        
        //sample string to test 
        //String arr[] = { "aaabb", "bbaaa", "cccbb","bbccc" };

	if (args.length <=1)
	{
		System.out.println ("Incorrect number of arguments");
		return;
	}
       
        String stems = findstem(args); //calling the method 
        System.out.println("LCS is "+stems+"."); //printing ouptut of method 
    }
}