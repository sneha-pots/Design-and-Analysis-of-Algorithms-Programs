DAA Lab Assignment 9 

This project consists of two programs and one bonus program. 

(1) Program 1: MatrixChain.java
To find the optimal, least cost order to perform matrix chain multiplication.

To compile: javac MatrixChain.java
To run: java MatrixChain

Sample input/output:
Enter number of matrices:
4
Enter dimensions for matrix chain:
    (Example: For A(20x30) multiplied with B(30x50), enter 20 30 50)

20 40 10 60 100
Matrices are: A B C D
Optimal Parenthesization:
((AB)(CD))
Optimal Cost: 88000

Logic:
- The number of matrices (n) and their dimensions (put in arr[n]) are entered by the user when prompted. 
- matrixChain() method finds the optimal cost of chain multiplication using bottom up approach (tabulation method).
- We split the matrix chain into all possible subexpressions and find the minimum cost of multiplying each subexpression. We add the costs together and add the cost of multiplying the resultant matrices too.
- We find the minimum cost of all subsequences of length L (2 <= L <= n), using the costs of smaller subsequences already calculated.
- bracket[i][j] stores optimal splitting point in subexpression from i to j.
-   m[i,j] = Minimum number of scalar multiplications needed to compute the 
        matrix A[i]A[i+1]...A[j] = A[i..j] where dimension of A[i] is p[i-1] x p[i] 
- Each entry in bracket[i,j] = k shows where to split the product arr i,i+1....j for the minimum cost.
- Then we call the Paranthesis() function to insert the parantheses in the matrix chain expession and print it out.
- We recursively put brackets around subexpression from i to bracket[i][j] and then subexpression from bracket[i][j] + 1 to j.

(2) Program 2: LCS.java
To find the LCS of two strings. 

To compile: javac LCS.java
To run: java LCS

Input: Enter the two strings through command line separated by a space. 
Output: LCS of <string1> and <string2> is <LCS>

Sample input/output.

Input: java LCS TAGTCACG AGACTGTC
Output: LCS of TAGTCACG and AGACTGTC is AGACG.
 
Logic:
- The two sequences are input through the command line. There is a sanity check here, as only two strings should be entered. 
- lcs is a method that takes four parameters. X and Y are the two strings/sequences inputted by the user and m and n are the length of the respective strings. It returns the length of the LCS of the two strings. 
- We build the 2D talbe L[m+1][n+1]. We add one because the first row and column are filled with 0's, so we need an extra row and an extra column. 
- The following steps build L[m+1][n+1] in bottom up fashion. If either i or j values is 0, the LCS value becomes 0. Else we keep filling the table according based on the case it falls under.  
- In case the last letters of both the sequences match, L[i][j] = = L[i-1][j-1] + 1. 
- If they don't match, we pick the maximum of L[i-1][j] and L[i][j-1]. 
- At the end, we return L[m][n] which is the final value of the length of the LCS. 
- We then print the LCS. We create a character array called lcs to store the LCS.
- Starting from the bottom right corner of the table we created earlier, we one by one store the characters in the character array lcs. 
- If the current character in both the strings are the same, then that character is part of the LCS. So we add that character to the lcs array, and reduce the values of i and j. 
- If the current character in both strings are not the same, we find the larger of the two and go in that direction.  

                                                                                          
(3) Bonus problem: LCSNStrings.java
To find the LCS of n strings. 

To compile: javac LCSNStrings.java
To run: java LCSNStrings

Input: Enter the strings through command line separated by a space. 
Output: The output with be the LCS. 

Sample input/output. 
Input: java LCSNStrings aaabb bbaaa cccbb bbccc
Output: LCS is bb. 

Input: java LCSNStrings earring earlobe earpiece earphone
Output: LCS is ear. 

Logic:
- We are given a list of strings sharing a common stem (LCS). The aim is to find and return that longest common substring, which is the steam of those words. 
- In the main function, we take the words through command line. A sanity check is in place to ensure the number of words we recieve are two or more. 
- We then call the findstem method. This methods return type is String. We pass the array of strings we got through the command line to this method. 
- In this method we find the number of words given using the array.length method. 
- We then choose the first argument as our reference string, and find the length of this as well. 
- We start by taking the first word from the list as a reference. We form all its substrings, and for each one, we iterate over the other words to see if it's a substring of those other words as well. 
- We initiate a new string called res where we will store the LCS on finding it. 
- Using two for loops, we generate all possible substrings of the reference string we stored earlier. 
- Using a third for loop, we check to see if each substring we find is common in all the words. 
- Each time it comes true, we store it in res, by using this logic: when the current substring is present in all the words, and its length is greater than the previously stored result, the res updates with the new substring. 
- We then return and print the string inside res, which is the LCS. 

Built With:
Java

Authors: 
Shagufta Anjum (19XJ1A0568)
Sneha Potluri (19XJ1A0572)
Group 7