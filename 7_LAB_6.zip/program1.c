#include <stdio.h>
#include <stdlib.h>

typedef struct item
{
    int no;
    double weight;
    double profit;
} item;

//Function declarations
void printData(item *items[], int n);
void knapsack(item *items[], int max_size, int n);

int main(int argc, char *argv[])
{
    if (argc < 5)
    {
        printf("Error: Too few arguments.\n");
        return 1;
    }

    //number of objects through command line argument
    int max_size = atoi(argv[1]);
    int n = atoi(argv[2]);

    if (max_size <= 0)
    {
        printf("Error: Knapsack size must be greater than 0.\n");
        return 1;
    }

    if (n < 2)
    {
        printf("Error: atleast 2 objects required.\n");
        return 1;
    }

    if (argc != ((2 * n) + 3))
    {
        printf("Error: invalid input.\n");
        return 1;
    }

    //Creating arrays of structs of items
    item *items[n];

    //Filling up item list with command line args
    for (int x = 3, y = 0, index = 1; x < 2 * n + 3; x++)
    {
        items[y] = (struct item *)malloc(sizeof(struct item)); //allocating memory for each item
        items[y]->no = index;
        index++;
        items[y]->weight = atoi(argv[x]);
        x++;
        items[y]->profit = atoi(argv[x]);
        y++;
    }

    //printing user input
    printf("Max capacity of knapsack: %d\n", max_size);
    printf("Number of items: %d\n", n);

    printf("\nItems list:\n");
    printf("%10s %10s %10s\n", "Item number", "Weight", "Profit");
    printData(items, n);

    //Calling function to solve knapsack problem
    knapsack(items, max_size, n);
    return 0;

    //Freeing memory
    for (int i = 0; i < n; i++)
    {
        free(items[i]);
    }
    free(items);
}

void knapsack(item *items[], int max_size, int n)
{
    //sorting the objects in descending order per profit to weight ratio
    item *temp; //temp item struct

    for (int i = 1; i < n; i++)
    {
        for (int j = 0; j < n - i; j++)
        {
            if ((items[j + 1]->profit / items[j + 1]->weight) > (items[j]->profit / items[j]->weight))
            {
                temp = items[j + 1];
                items[j + 1] = items[j];
                items[j] = temp;
            }
        }
    }

    //printing jobs table after sorted
    printf("\nSorted items list (descending order as per profit to weight ratio):\n");
    printf("%10s %10s %10s\n", "Item number", "Weight", "Profit");
    printData(items, n);

    //Solution vector
    double x[n];
    double profit = 0;

    for (int i = 0; i < n; i++)
    {
        x[i] = 0.0;
    }

    //Finding fractions for maximum profits
    for (int i = 0; i < n; i++)
    {
        if (max_size > 0)
        {
            if (items[i]->weight <= max_size)
            {
                max_size = max_size - items[i]->weight;
                profit = profit + items[i]->profit;
                x[items[i]->no - 1] = 1.0;
            }
            else
            {
                x[items[i]->no - 1] = max_size / items[i]->weight;
                profit = profit + (items[i]->profit * (max_size / items[i]->weight));
                max_size = 0;
            }
        }
        else
            break;
    }

    printf("\nSolution:\n");
    printf("%10s %15s\n", "Item number", "Fraction added to knapsack");
    for (int i = 0; i < n; i++)
    {
        printf("%10i %15lf\n", i + 1, x[i]);
    }

    printf("\nMaximum profit = %lf\n", profit);
}

void printData(item *items[], int n)
{
    char empty[1] = " ";
    for (int i = 0; i < n; i++)
    {
        printf("%10i %7s%.1lf %7s%.1lf\n", items[i]->no, empty, items[i]->weight, empty, items[i]->profit);
    }
}
