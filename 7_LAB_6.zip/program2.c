#include <stdio.h>
#include <stdlib.h>

#define MAX 100
  
//creating structure 
typedef struct Job 
{
    int no;
    int deadline;
    int profit;
} Job;

void jobSequencing (Job * jobs[], int n);

int minValue (int x, int y) 
{
    if (x < y)
    return x;
    return y;
}

int main (int args, char *argv[]) 
{
    //variables
    int i, j, n = 0, x, y = 0, z = 1;
  
    if (args == 1)
    {
        printf ("Error: please enter input");
        return 0;
    }
  
    //number of jobs through command line argument
    n = atoi (argv[1]);
  
    if (args != ((2 * n) + 2))
    {
        printf ("Error: invalid input.\n");
        return 0;
    }
  
    if (n > 100)
    {
        printf ("Error: no more than 100 jobs.");
        return 0;
    }
  
    if (n < 2)
    {
        printf ("Error: please enter at least 2 jobs.");
        return 0;
    }
  
    Job * jobs[n];
  
    for (x = 2; x < ((2 * n) + 1); x++)
    {
        jobs[y] = (struct Job *) malloc (sizeof (struct Job));	//allocating memory 
        jobs[y]->no = z;
        z++;
	    jobs[y]->deadline = atoi (argv[x]);
        x++;
        jobs[y]->profit = atoi (argv[x]);
        y++;
    } 
 
    //printing user input in a table 
    printf ("Your input is:\n");
    printf ("%10s %10s %10s\n", "Job number", "Deadline", "Profit");
  
    for (i = 0; i < n; i++)
    {
        printf ("%10i %10i %10i\n", jobs[i]->no, jobs[i]->deadline,
		jobs[i]->profit);
    }
  
    Job * temp;	//temp
  
    //sorting the jobs profit wise in descending order
    for (i = 1; i < n; i++)
    {
        for (j = 0; j < n - i; j++)
	    {
	        if (jobs[j + 1]->profit > jobs[j]->profit)
	        {
	            temp = jobs[j + 1];
	            jobs[j + 1] = jobs[j];
	            jobs[j] = temp;
	        }
	    }
    }
    //printing jobs table after sorted
    printf ("Sorted table of profits of jobs in descending order:\n");
    printf ("%10s %10s %10s\n", "Job number", "Deadline", "Profit");
  
    for (i = 0; i < n; i++)
    {
        printf ("%10i %10i %10i\n", jobs[i]->no, jobs[i]->deadline,
		jobs[i]->profit);
    }
  
    jobSequencing (jobs, n);
    return 0;
}

void jobSequencing (Job * jobs[], int n) 
{
    int i, j, k; //variables
    int timeslot[MAX]; //free time slots
    int filledTimeSlot = 0;	//filled time slots
    int dmax = 0; // maximum deadline 
  
    //finding max deadline value
    for (i = 0; i < n; i++)
    {
        if ((jobs[i]->deadline) > dmax)
	    {
	        dmax = jobs[i]->deadline;
	    }
    }
  
    //free time slots initially set to -1 
    //-1 denotes that it's empty 
    for (i = 1; i <= dmax; i++)
    {
        timeslot[i] = -1;
    }

    for (i = 1; i <= n; i++)
    {
        k = minValue (dmax, jobs[i - 1]->deadline);
        while (k >= 1)
	    {
	        if (timeslot[k] == -1)
	        {
	            timeslot[k] = i - 1;
	            filledTimeSlot++;
	            break;
            }
	        k--;
	    }
	    //if time slot is full, break out
	    if (filledTimeSlot == dmax)
	    {
	        break;
	    }
    }
  
    //printing required jobs
    printf ("\nSolution vector of job numbers to be completed for maximum profit: ");
 
    for (i = 1; i <= dmax; i++)
    {
        if (timeslot[i]!=-1)
        {
            printf ("%d", jobs[timeslot[i]]->no);
            if (i < dmax)
	        {
	            printf (", ");
	        }
        }
    }
    printf (".\n");
  
    //profit obtained
    int maxprofit = 0;
  
    for (i = 1; i <= dmax; i++)
    {
        if (timeslot[i]!=-1)
        {
            maxprofit = maxprofit + (jobs[timeslot[i]]->profit);
        }
    }
    printf ("The maximum profit obtained by completing these jobs is %d.\n",maxprofit);
}

