DAA Lab Assignment 6

Description:
	This assignment consists of 2 programs:

(1) program1.c - Knapsack problem:

How to provide input:
• Input is given through command line arguments by the user. 
• First argument: Maximum capacity of knapsack
• Second argument: Number of items 
• The next arguments are to be the item weights and profits.
• Input sample: 
	./a.out 15 6 2 10 3 5 5 12 7 6 1 20 4 4
	Here, 15 is maximum capacity of the knapsack. 
	The number of items is 6.
	Item 1 has weight 2 and profit 10. Item 2 has weight 3 and profit 5. Item 3 has weight 5 and profit 12(and so on).

Output format:
•	Firstly, the input as provided by the user is displayed in tabular form. 
•	Next, the details are sorted in decreasing order of the ratio of profit to weight and displayed.
•	Lastly, we display the solution vector of the knapsack problem and the maximum possible profit.
•	Example: For input ./a.out 15 4 4 7 9 2 5 6 8 3
	The output is:

Max capacity of knapsack: 15
Number of items: 4

Items list:
Item number     Weight     Profit
         1        4.0        7.0
         2        9.0        2.0
         3        5.0        6.0
         4        8.0        3.0

Sorted items list (descending order as per profit to weight ratio):
Item number     Weight     Profit
         1        4.0        7.0
         3        5.0        6.0
         4        8.0        3.0
         2        9.0        2.0

Solution:
Item number Fraction added to knapsack
         1        1.000000
         2        0.000000
         3        1.000000
         4        0.750000

Maximum profit = 15.250000

Logic used:
•	We take the max capacity of the knapsack and the weights & profits of each object from the user.
•	We store the details of each object (including item number) in a struct and create an array of these item structs using malloc(). This is displayed to the user in tabular form.
•	We pass the array, the number of items and the size of the knapsack to a function called knapsack() which solves the knapsack problem.
•	The knapsack() function first calculates the profit to weight ratio for each item and sorts them in descending order of the ratio. This is displayed to the user in a table.
•	An object with a higher profit to weight ratio is more profitable, and it should be added to the knapsack first.
•	We created a solution vector (array) called x[n] to store the fractions of each item that will be added to the knapsack and initialize it with 0s.
•	We then run the algorithm and iterate through the array of items sorted in descending order.
•	If the weight of the item is lower than the knapsack’s current capacity, we add the whole object to it. We subtract the weight of the item from the knapsack’s capacity. The total profit is incremented by the profit of that item. 
•	If the weight of the item is higher than the current capacity, we add the fraction of it that fits (given by capacity/item_weight). The total profit is incremented by the fractional profit.
•	The solution vector is updated with 1.0 at the position corresponding to the original index of the item when the whole object is added, and with the fraction (0 < xi < 1) when the item is fractionally added.
•	We stop when the knapsack has 0 capacity left. 
•	The solution vector and total maximum profit is displayed at the end.
			  	
(2)program2.c - Job sequencing with deadlines: 

How to provide input:
• Input is given through command line arguments by the user for this problem. 
• First argument: number of jobs (between 2 and 100, inclusive)
• The next arguments are to be the deadlines and profits of the jobs.
• Input sample: 
	• ./a.out 7 2 40 4 15 3 60 2 20 3 10 1 45 1 55
	Here, 7 is the number of jobs. Then, 2 is the deadline of the first job, and 40 is the profit of the job. Next, 4 and 15 are the deadline and profit of the second job, respectively. 

Output details:
• Firstly, the input as provided by the user is displayed in tabular form. 
• Next, the same details are displayed, but they are sorted in decreasing order of profit. 
• Then, the solution vector of the jobs that should be done for maximum profit is displayed. 
• Lastly, the maximum profit possible if these jobs are executed is displayed. 
• Output sample:
  For input: ./a.out 7 2 40 4 15 3 60 2 20 3 10 1 45 1 55
  The output would be: 

Your input is:                                                                                                                         
Job number   Deadline     Profit                                                                                                       
         1          2         40                                                                                                       
         2          4         15                                                                                                       
         3          3         60                                                                                                       
         4          2         20                                                                                                       
         5          3         10                                                                                                       
         6          1         45                                                                                                       
         7          1         55                                                                                                       
Sorted table of profits of jobs in descending order:                                                                                   
Job number   Deadline     Profit                                                                                                       
         3          3         60                                                                                                       
         7          1         55                                                                                                       
         6          1         45                                                                                                       
         1          2         40                                                                                                       
         4          2         20                                                                                                       
         2          4         15                                                                                                       
         5          3         10                                                                                                       
                                                                                                                                       
Solution vector of job numbers to be completed for maximum profit: 7, 1, 3, 2                                                          
The maximum profit obtained by completing these jobs is 170   

Logic used:
• In the int main function, after declaration of variables, the first argument from command line is taken and stored in n, which is the variable for the total number of jobs. 
• Error messages are written for situations where number of jobs is not between 2 and 100, or if the total number of command line arguments is not correct. 
  The total number of inputs should be 2 times the number of jobs plus 1, because each job has 2 parameters, plus the argument for number of jobs. 
  The serial numbers of the jobs are generated within the code itself; no user input is required for it. 
• Next, the structure is declared. Using a for loop, we allocate memory and take the command line arguments and store them as required. We use the atoi function to convert the arguments into integers. 
• Now that it's stored, we display the input to the user in tabular form at this point, so they can easily see what they have given as input. 
• Next, we sort the jobs based on profit using two for loops. At this point, we print the table in sorted form again for the user to see. 
• Now, we call the jobSequencing function. In this function, we declare variables, and find the maximum deadline value so that we can fill up slots up to that number only. 
• Using for loops, we fill the time slots (timeslot array). When any timeslot value is -1, it means it's empty and can be filled. When the filledTimeSlot variable is equal to variable dmax, it means it's full. 
• Now we have the solution vector. We print this only when the timeslot value is not -1 (meaning it's full). It shows the order in which the jobs should be completed to obtain the maxmimum profit. 
• Lastly, the maximum profit is calculated using simple recursive addition and an if condition, and is printed.  

Built With:
C

Authors:
Shagufta Anjum (19XJ1A0568)
Sneha Potluri (19XJ1A0572)
Group 7
