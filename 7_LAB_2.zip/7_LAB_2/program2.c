#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

struct student
{
    char id[20];
    char name[50];
    int group;
};

void swap(struct student *x, struct student *y) //Utility fn
{
    struct student temp = *x;
    *x = *y;
    *y = temp;
}

int partition(struct student arr[], int low, int high)
{
    struct student pivot = arr[high]; // Choosing last element as pivot
    int i = (low - 1);                // Index of smaller element

    for (int j = low; j <= high - 1; j++) //Traversing array
    {
        //Compare group.
        //If group is equal, check roll no.
        //If roll no is equal, check group.
        if (arr[j].group < pivot.group || (arr[j].group == pivot.group && strcmp(arr[j].id, pivot.id) < 0) || (arr[j].group == pivot.group && strcmp(arr[j].id, pivot.id) == 0 && strcmp(arr[j].name, pivot.name) < 0))
        {
            i++;
            swap(&arr[i], &arr[j]);
        }
    }
    swap(&arr[i + 1], &arr[high]); //Placing pivot in right location
    return (i + 1);
}

void quickSort(struct student arr[], int low, int high)
{
    if (low < high)
    {
        int pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);  //Calling fn on left array
        quickSort(arr, pi + 1, high); //Calling fn on right array
    }
}

void mergeSort(struct student arr[], int low, int high, int mid)
{
    int i, j, k;
    int left_size = mid - low + 1;
    int right_size = high - mid;

    struct student left[left_size];
    struct student right[right_size];

    for (i = 0; i < left_size; i++) //Copying left half of array into left[]
    {
        strcpy(left[i].id, arr[i + low].id);
        strcpy(left[i].name, arr[i + low].name);
        left[i].group = arr[i + low].group;
    }

    for (j = 0; j < right_size; j++) //Copying right half of array into right[]
    {
        strcpy(right[j].id, arr[mid + 1 + j].id);
        strcpy(right[j].name, arr[mid + 1 + j].name);
        right[j].group = arr[mid + 1 + j].group;
    }

    i = 0;
    j = 0;
    k = low;

    int result;
    while (i < left_size && j < right_size)
    {
        //sorting based on group, then roll number
        if (left[i].group < right[j].group)
        {
            strcpy(arr[k].id, left[i].id);
            strcpy(arr[k].name, left[i].name);
            arr[k].group = left[i].group;
            i++;
        }

        else if (left[i].group > right[j].group)
        {
            strcpy(arr[k].id, right[j].id);
            strcpy(arr[k].name, right[j].name);
            arr[k].group = right[j].group;
            j++;
        }

        else if (left[i].group == right[j].group)
        {
            int result = strcmp(left[i].id, right[j].id);
            if (result < 0)
            {
                strcpy(arr[k].id, left[i].id);
                strcpy(arr[k].name, left[i].name);
                arr[k].group = left[i].group;
                i++;
            }

            else if (result > 0)
            {
                strcpy(arr[k].id, right[j].id);
                strcpy(arr[k].name, right[j].name);
                arr[k].group = right[j].group;
                j++;
            }
        }
        k++;
    }

    while (i < left_size)
    {
        strcpy(arr[k].id, left[i].id);
        strcpy(arr[k].name, left[i].name);
        arr[k].group = left[i].group;
        i++;
        k++;
    }

    while (j < right_size)
    {
        strcpy(arr[k].id, right[j].id);
        strcpy(arr[k].name, right[j].name);
        arr[k].group = right[j].group;
        j++;
        k++;
    }
}

void find_mid(struct student arr[], int low, int high)
{
    if (low < high)
    {
        int mid = ((low + high) / 2);

        find_mid(arr, low, mid);      //Left
        find_mid(arr, mid + 1, high); //Right

        mergeSort(arr, low, high, mid);
    }
}

int main(int argc, char *argv[])
{
    if (argc == 2)
    {
        int algo = atoi(argv[1]); //Option for algorithm

        if (algo == 1 || algo == 2)
        {
            //Opening input file
            FILE *fp;
            fp = fopen("input_data.txt", "r");
            if (fp == NULL)
            {
                printf("Error opening file\n");
                return 1;
            }

            //Counting number of lines in file
            int total = 0;
            char c;
            while ((c = fgetc(fp)) != EOF)
            {
                if (c = '\0' || c == '\n')
                    total++;
            }

            rewind(fp);

            struct student slist[total]; //Creating array of structs

            //Reading from input file
            int i = 0;
            while (fscanf(fp, "%s %s %i", slist[i].id, slist[i].name, &(slist[i].group)) != EOF)
            {
                i++;
            }

            //Running sort algorithm
            if (algo == 1)
                find_mid(slist, 0, total - 1);
            else
                quickSort(slist, 0, total - 1);

            //Opening output file
            fp = fopen("output2.txt", "w");
            if (fp == NULL)
            {
                printf("Error opening file\n");
                return 1;
            }

            //Writing to output file
            for (int j = 0; j < total; j++)
            {
                fprintf(fp, "%s %s %i\n", slist[j].id, slist[j].name, slist[j].group);
            }

            fclose(fp);
            return 0;
        }
        else
        {
            printf("\nInvalid input.");
            return 1;
        }
    }
    else
    {
        printf("\nInvalid input.");
        return 1;
    }
}
