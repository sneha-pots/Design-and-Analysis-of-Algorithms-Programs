DAA Lab Assignment 2

Description:
    This project consists of two programs to sort the given file of student records using two different sorting algorithms, Merge Sort and Quick Sort.

program1.c
    To sort the records in ascending order based on one of three parameters - Roll number, Name or Group number - which is to be provided by the user via command line arguments. Output is written to the output1.txt file.

    First argument: 1 (for Merge sort) or 2 (for Quick sort)
    Second argument: 1 (for roll number) or 2 (for name) or 3 (for group)
    Input sample: ./a.out 1 3

program2.c
    To sort the records in ascending order by comparing group number, then roll number, and finally, name. The algorithm to be used must be specified by the user. Output is written to the output2.txt file.
    User Argument: 1 (for Merge sort) or 2 (for QUick sort)
    Input sample: ./a.out 2

Note: Output file may need to be reloaded to see changes.

Logic used:
- The data from the input file is stored in an array of structures (slist). 
- Each struct has fields Roll no, Name and Group number.
- We find the total number of lines in the input file using fgetc function.
- User gives choice of algorithm (algo) and parameter for sorting (opt).

- Merge sort:

•	We first call the find_mid() function. The middle element (mid) is determined and find_mid() is called  recursively on the left and right halves of the array. 
•	This continues until only one array is left in each sublist, which can now be considered 'sorted'. 
•	The sublists are now merged to form sorted sublists. To merge them, we iterate over them using i and j. k is the sorted sublist index, and is initially set to equal to low. 
•	Elements arr[i] and arr[j] are compared. The smaller element among two becomes a new element of the sorted list, and is assigned to arr[k]. Either i or j is then incremented. 
•	After each element is added, k is incremented. We continue until the combined sorted sublist covers all the elements of both the sublists.
•	In program1.c, depending on the user’s choice (opt), we compare roll no, name or the group no to make the swaps. In program2.c, we first compare group. If group is same, we compare roll no, and lastly the name. 
•	After all the merging, the final array is sorted.


- Quick Sort: 

•	The quickSort() function calls the partition() function and passes to it the array of structs(arr), the first index (low) and last index(high). 
•	The last element arr[high] is chosen as the pivot. 
•	The index of smaller (or equal to) element is i. Starting from the left, we iterate through the array. 
•	If we find any element smaller than the pivot, we increment i and swap the current element with arr[i]. Otherwise, there is no change to the array. 
•	In program1.c, depending on the user’s choice (opt), we compare roll no, name or the group no to make the swaps. In program2.c, we first compare group. If group is same, we compare roll no, and lastly the name. 
•	After traversing the array, we swap the pivot with arr[i+1]. This way, all the elements that are smaller than the pivot are to its left, and all elements greater than it are on its right. Pivot index (i+1) is returned.
•	We then run quickSort() recursively on subarrays formed on the left and right of the pivot. This continues till all elements are sorted. 

Built With:
C

Authors:
Shagufta Anjum (19XJ1A0568)
Sneha Potluri (19XJ1A0572)
Group 7

