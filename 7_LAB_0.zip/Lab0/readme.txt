DAA Lab Assignment 0

Description:
    This assignment consists of two programs that deal with various aspects of file handling in C.

program1.c
•	To read the contents of an input file and write them to an output file.
•	We create a file pointer (fp) and open the input file in read mode. We create another file pointer (fo) and open the output file in write mode.
•	We use the fgetc function to read each character (ch) from the input file until we reach EOF, and subsequently we write each character to the output file using fprintf.


program2.c
•	To count the number of characters, words, and lines in a file.
•	We create a file pointer (fp) and open the input file in read mode.
•	We use the fgetc function to read each character (ch) from the input file until we reach EOF.
•	For each character except null, we increment char_count by 1.
•	Flag is set to 1 initially. If ch is a space or tab or null character, we increment word_count only if flag == 1. Then, we set flag = 0.
•	If flag = 1, it means we encounter a space the first time after a word, and so we can count the word. If flag = 0, it’s not a new word.
•	If ch is a null character, we increment line_count by 1.
•	The results are printed to the output file using fprintf.

Built With:
C

Authors:
Shagufta Anjum (19XJ1A0568)
Sneha Potluri (19XJ1A0572)
Group 7

