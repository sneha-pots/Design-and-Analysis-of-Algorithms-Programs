#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{

  //Opening input file
  FILE *fp;
  fp = fopen("input.txt", "r");
  if (fp == NULL)
  {
    printf("Error opening file\n");
    return 1;
  }

  //Opening output file
  FILE *fo;
  fo = fopen("output1.txt", "w");
  if (fo == NULL)
  {
    printf("Error opening file\n");
    return 1;
  }

  //Reading from input file
  char ch;
  while ((ch = fgetc(fp)) != EOF)
  {
    fprintf(fo, "%c", ch); // Writing to output file
  }

  fclose(fp);
}
