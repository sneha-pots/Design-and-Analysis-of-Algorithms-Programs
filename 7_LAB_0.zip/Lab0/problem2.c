#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  int char_count = 0, word_count = 0, line_count = 0;

  //Opening input file
  FILE *fp;
  fp = fopen("input.txt", "r");
  if (fp == NULL)
  {
    printf("Error opening file\n");
    return 1;
  }

  //Reading from input file
  char ch;
  int flag = 0;
  while ((ch = fgetc(fp)) != EOF)
  {
    if (ch != '\n')
      char_count++;

    if (ch == ' ' || ch == '\t' || ch == '\0' || ch == '\n')
    {
      if (flag)
      {
        flag = 0;
        word_count++;
      }

      if (ch = '\0' || ch == '\n')
        line_count++;
    }
    else
      flag = 1;
  }

  printf("Number of characters in this file is %d\nNumber of words in this file is %d\nNumber of lines in this file is %d\n", char_count, word_count, line_count);

  //Opening output file
  fp = fopen("output.txt", "w");
  if (fp == NULL)
  {
    printf("Error opening file\n");
    return 1;
  }

  //Printing into output file
  fprintf(fp, "Number of characters in this file is %d\n", char_count);
  fprintf(fp, "Number of words in this file is %d\n", word_count);
  fprintf(fp, "Number of lines in this file is %d\n", line_count);

  fclose(fp);
}
