#include <stdio.h>
#include <stdlib.h>

// Returns number of ways of reaching n'th stair in steps of 1 or 2
int countWays(int n, int m)
{
    int res[n + 1];
    int temp = 0;
    res[0] = 1;
    for (int i = 1; i <= n; i++)
    {
        int s = i - m - 1;
        int e = i - 1;
        if (s >= 0)
        {
            temp -= res[s];
        }
        temp += res[e];
        res[i] = temp;
    }
    return res[n];
}

int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        printf("Invalid input: number of arguments.\n");
        return 1;
    }

    int n = atoi(argv[1]);

    if (n <= 0 || n >= 100000)
    {
        printf("Number of Stairs is out of bounds.\n");
        return 1;
    }

    int m = 2;
    printf("Number of ways = %d\n", countWays(n, m));
    return 0;
}