// C++ program to find maxium number of meetings
#include <stdio.h>

// Structure for storing starting time, finishing time and position of meeting.
typedef struct meeting
{
    int start;
    int end;
    int pos;
} meeting;

//Helper functions to sort the meeting list
void merge(meeting meet[], int l, int m, int r);
void sortMeetings(meeting meet[], int l, int r);

//Calculates the max number of meetings possible, and which meetings they are
void maxMeetings(meeting meet[], int n)
{
    //Sorting the meetings according to the end timings (ascending order)
    sortMeetings(meet, 0, n - 1);

    int i, j;
    printf("The following meetings are selected: \n");

    // The first meeting always gets selected
    i = 0;
    printf("%d ", meet[i].pos + 1);

    //Count tracks the number of meeting selected
    int count = 1;

    // Iterating through the of the sorted meetings
    for (j = 1; j < n; j++)
    {
        // If the meeting has start time greater than or
        // equal to the end time of previous selected meeting,
        // we select it and print it out
        if (meet[j].start >= meet[i].end)
        {
            printf("%d ", meet[j].pos + 1);
            i = j;
            count++;
        }
    }
    printf("\nMaximum meetings: %d\n", count);
}

int main()
{
    int n; //number of meeetings
    printf("Enter total number of meetings: ");
    scanf("%d", &n);

    if (n <= 0 || n >= 100000)
    {
        printf("Number of meetings is out of bounds.\n");
        return 1;
    }

    //Array of meeting structs (list of meetings)
    meeting meet[n];

    printf("Enter start times: \n");
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &meet[i].start);
    }

    printf("Enter end times: \n");
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &meet[i].end);
    }

    for (int i = 0; i < n; i++)
    {
        meet[i].pos = i;
    }

    // Function call
    maxMeetings(meet, n);

    return 0;
}

void merge(meeting meet[], int l, int m, int r)
{
    int i, j, k;
    int n1 = m - l + 1;
    int n2 = r - m;

    meeting L[n1], R[n2];

    for (i = 0; i < n1; i++)
        L[i] = meet[l + i];
    for (j = 0; j < n2; j++)
        R[j] = meet[m + 1 + j];

    i = 0;
    j = 0;
    k = l;
    while (i < n1 && j < n2)
    {
        if (L[i].end <= R[j].end)
        {
            meet[k] = L[i];
            i++;
        }
        else
        {
            meet[k] = R[j];
            j++;
        }
        k++;
    }

    while (i < n1)
    {
        meet[k] = L[i];
        i++;
        k++;
    }

    while (j < n2)
    {
        meet[k] = R[j];
        j++;
        k++;
    }
}

void sortMeetings(meeting meet[], int l, int r)
{
    if (l < r)
    {
        int m = l + (r - l) / 2;
        sortMeetings(meet, l, m);
        sortMeetings(meet, m + 1, r);
        merge(meet, l, m, r);
    }
}
