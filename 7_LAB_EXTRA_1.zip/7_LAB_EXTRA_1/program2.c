//2. Largest Number with Given Sum

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int large(int N, int S);

int main(int args, char *argv[])
{
  //error checks
  if (args != 3)
  {
    printf("Invalid input: number of arguments\n");
    return 0;
  }

  int N, S;
  N = atoi(argv[1]);

  if (N <= 0 || N >= 10000)
  {
    printf("Number of digits is out of bounds.\n");
    return 1;
  }

  S = atoi(argv[2]);

  if (S <= 0 || S >= 1000000)
  {
    printf("Sum of digits is out of bounds.\n");
    return 1;
  }

  if (S > (9 * N))
  {
    printf("-1\n");
    return 0;
  }
  if (N < 1 || N > 1000)
  {
    printf("Invalid input: value of N\n");
    return 0;
  }
  if (S < 0 || S > 1000000)
  {
    printf("Invalid input: value of S\n");
    return 0;
  }

  large(N, S);

  return 0;
}

int large(int N, int S)
{
  if (S == 0)
  {
    if (N == 1)
    {
      printf("0\n");
      return 0;
    }

    else
    {
      printf("-1\n");
      return 0;
    }
  }

  //array to store digits
  int res[N];

  //filling digits
  for (int i = 0; i < N; i++)
  {
    if (S >= 9)
    {
      res[i] = 9;
      S = S - 9;
    }

    else
    {
      res[i] = S;
      S = 0;
    }
  }

  for (int i = 0; i < N; i++)
  {
    printf("%d", res[i]);
  }
  printf("\n");
}
