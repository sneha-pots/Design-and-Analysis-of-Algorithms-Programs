DAA Lab Assignment 1 (EXTRA)

This assignment consists of 3 programs:

(1)	program1.c: N Meetings in One Room	

Input/Output format:
•	No command line arguments are required.
•	The user is prompted (using scanf) to enter values for number of meetings, start time of each meeting and end time of each meeting.
•	The indices of selected meetings and the total number of meetings is displayed.

Sample run:
Enter total number of meetings: 4
Enter start times:
1 7 2 9
Enter end times:
8 3 6 1
The following meetings are selected:
3 1
Maximum meetings: 2

Logic Used:  
•	Number of meetings (0 < n < 10^5), meeting start times and end times are taken as user input.
•	The details of each meeting are stored in a struct. We create an array of structs to store the meeting list.
•	We sort the array in increasing order of the end time of the meetings used merge sort algorithm.
•	The first meeting in the sorted array is selected and printed. 
•	We use count variable to keep a track of how many meetings are selected so far.
•	We iterate from the second meeting in the array to last one. If the start time of the meeting is greater than the end time of the previously selected meeting, we select it and print it out. Count variable is incremented.
•	Finally, we print out the number of meetings selected, which is the maximum possible number.


	(2) program2.c: Largest Number with Given Sum

How to give input:
The inputs of this program are given as command line arguments. 
First is the value of N (the number of digits in the passcode) and second is the value of S (the sum of the digits of the passcode).

Input sample: ./a.out <N> <S>
		./a.out 3 27
		./a.out 5 12 

Logic used:
•	At the beginning of the program, all the error checks are there. The program returns an error for the following cases
    -	if the number of input arguments is not 2 
    -	if values of N (0 < N < 10^4) and S (0 < S < 10^6)are not within the given constraints
•	This program returns the value -1 if there is no possible number for the given values. It does this by checking if the sum is greater than 9 times the number of digits. Since 9 is the highest possible value of each digit, this number won't be possible, and -1 will be printed. 
•	Next the large function is called, and the value of N and S are passed to it. 
•	In the large function, the first thing that is checked is if the sum (S) is 0. If it's 0, and the number of digits is 1, then we can confirm that the passcode is 0 itself. But, if there is more than 1 digit, then this number is not possible. So, we print -1, as given in the instructions to print -1 if a certain number is not possible. 
•	Now, if S is not 0, we keep filling up an array with 9, if the value of S permits (if S>=9). If S is less than 9, we fill it up with the value of S and make the rest of the values 0. We then decrement S value by 9 each time (or make it 0 if it's less than 9), and decrement N value by 1 each time. This function is recursively called until N becomes 0, after which, we print the array as a number using a for loop. 


    (3) program3.c: Count Ways to Reach the Nth Stair

How to give input:
There is one command line argument, the number of stairs.

Sample run:
    Input: ./a.out 5 (Here, the number of stairs is 5)
    Output: Number of ways: 8

Logic Used:
•	Here we implement a Dynamic Programming approach and make use of the Sliding window technique to implement it in O(n) time.
•	The number of stairs = ‘n’ is taken as a command line argument (0 < n < 10^5).
•	‘m’ is the length of the sliding window, or the number of stairs we keep a track of at any given time. Since we are considering that a person can climb at most 2 steps at a time, we take m = 2.
•	For the ith stair, we keep a track of the sum of last m possible stairs from which we can climb to the ith stair. 
•	We create an array called res to keep track of the number of possibilities after each iteration.
•	We loop through all the stairs from 1 to n.
•	Instead of running an inner for loop, we maintain the result of the inner loop in a temporary variable called temp.
•	In each step, we remove the elements of the previous window and add the element of the current window and update the sum to the res array.
•	After looping through all the stairs, the entry in the nth position of the res array will give the total possible ways to climb n stairs by taking atleast 1 and atmost m steps at a time.


Built With:
C

Authors:
Sneha Potluri (19XJ1A0572)
Shagufta Anjum (19XJ1A0568)
Group 7
