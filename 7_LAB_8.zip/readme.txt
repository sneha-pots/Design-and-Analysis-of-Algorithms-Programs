DAA Lab Assignment 8

This project consists of two programs. 

(1) program1.c : Travelling Salesperson Problem (TSP)

We are given a set of cities and the distance between each pair of cities in a matrix form. Using this, we must find the shortest possible route for a salesman to visit every city once and returns to his starting point.
We use dynamic programming by dividing the problem into sub-problems. 

Input/Output samples:
Sample1:

Enter the number of cities: 4                                                                                                   
                                                                                                                                
Enter the cost matrix row by row. Seperate the elements by spaces.                                                              
                                                                                                                                
Enter elements of row 1:0 10 15 20                                                                                              
                                                                                                                                
Enter elements of row 2:10 0 35 25                                                                                              
                                                                                                                                
Enter elements of row 3:15 35 0 30                                                                                              
                                                                                                                                
Enter elements of row 4:20 25 30 0 '                                                                                            
                                                                                                                                                                                                                                                    
Your cost matrix is:                                                                                                            
0       10      15      20                                                                                                      
10      0       35      25                                                                                                      
15      35      0       30                                                                                                      
20      25      30      0   
                                                                                                    
Your shortest path is: 1--->2--->4--->3--->1  
                                                                                                         
Minimum cost is 80.


Sample2:

Enter the number of cities: 4                                                                                                   
                                                                                                                                
Enter the cost matrix row by row. Seperate the elements by spaces.                                                              
                                                                                                                                
Enter elements of row 1:0 10 15 20                                                                                              
                                                                                                                                
Enter elements of row 2:5 0 9 10                                                                                                
                                                                                                                                
Enter elements of row 3:6 13 0 12                                                                                               
                                                                                                                                
Enter elements of row 4:8 8 9 0                                                                                                 
                                                                                                                                                                                                                                                              
Your cost matrix is:                                                                                                            
0       10      15      20                                                                                                      
5       0       9       10                                                                                                      
6       13      0       12                                                                                                      
8       8       9       0                                                                                                       
                                                                                                                                
Your shortest path is: 1--->2--->4--->3--->1   
                                                                                 
Minimum cost is 35.

Logic Explanation:
- We first take the input from the user using the input() function. Using scanf method, we store the number of cities, and the cost matrix entered by them. 
- We then display the cost matrix for convenience. 
- Next we try to find the minimum cost using the mincost() function. 
- We considering city 1 as the starting and ending point. 
- For every other vetex (i), we find the minimum cost path using 1 as the starting point and i as the ending point. We make sure all vertices appear only once. 
- If the cost of this path is cost(i), the cost of the entire cycle would be cost (i) + dist(i,1). Dist(i,1) is the distance from vertex i to vertex 1. 
- To calculate cost(i), we use a recursive function. Say c(s,i) is the minimum cost path visiting each vertex in s exactly once, starting from 1 and ending at i. 
- We start with all subsets of size 2 and calculate c(s,i) for every subset of s. Then we calculate the value for subsets of size 3, and keep increasing. 
- If size of S is 2, then S must be {1, i},C(S, i) = dist(1, i) 
- Else if size of S is greater than 2, C(S, i) = min { C(S-{i}, j) + dis(j, i)} where j belongs to S, j != i and j != 1.
- Once we find all the cost(i) and dist(i,1) values, we find the minimum of them all. 
- We then print the path and cost of this. 

(2) Reliability.java : Reliability Design Problem

To compile: javac Reliability.java
To run: java Reliability

Input/Output sample:
Enter the total budget:
105
Enter number of machines:
3
Enter the Costs and Reliabilities of each machine (c1 r1 c2 r2 ...):
30 0.9 20 0.8 15 0.5

Maximum reliability of system: 0.648
2.0 copies of machine 3 of cost 15
2.0 copies of machine 2 of cost 20
1.0 copies of machine 1 of cost 30

Logic Explanation:
- We take input from the user using the Scanner class: the total budget (b), number of machines (n) and the costs & reliabilities of each machine (stored in data matrix).
- Costs are added to array c and reliabilities are put in array r.
- We create a 2D array B to store the budgets for each machine. It is initialized with -1. The 2D array M stores the machine numbers.
- We call the reliability method to calculate maximum reliability of the system. We have appropriate base cases in the recursive method.
- The max possible copies of a machine is calculated by Math.floor(total budget/cost of the machine).
- The find the probability of the machine failing as (1 - r[i]). For m copies to fail, probability is (1-r[i]^m). So, the reliability of m copies of a machine is (1 - (1 - r[i])^m). The highest reliability is max1 which is stored in B, and the number of copies corresponding is m which is stored in M.
- If there is only 1 machine left, we can simply return max1. But if there are more, we need subtract the cost of that from the total budget, and calculate the reliability as (1 - (1 - r[i])^m) + reliability(remaining machines) by calling the method recursively.  
- The reliability() method returns the maximum reliability of the total system, which is printed out.
- Then we call the printCost() method which prints out the number of machines of each kind along with individual costs.
- printCost() uses the 2D array M. We start with the last machine and print out the corresponding entry in M for budget b. Then we subtract cost of that machine from b. Then the max copies of next machine are found and printed using the updated budget. We repeat for all machines.

Built With:
C and Java

Authors: 
Shagufta Anjum (19XJ1A0568)
Sneha Potluri (19XJ1A0572)
Group 7