import java.lang.Math;
import java.util.Scanner;
	
public class Reliability {
	
	static double [][] B = new double [20][75001];
	static double [][] M = new double [20][75001];
	
	double reliability(int b, double r[], int c[], int i){

		/* base cases */

		if(B[i][b] != -1)
			return B[i][b];
		if (b<0)
			return 0.0;
		else if (b==0 && i>0)
			return 0.0;

		else if (b>=0 && i==0)
		{     
			double temp = 0;
		
			double max1 = 0;
			double n =  Math.floor(b/c[i]);
			//System.out.println(n);
			for(int m = 1; m <= n; m++){
				double rel = (1-Math.pow((1-r[i]), m));
				//System.out.println(rel);
				if (max1 < rel){
					max1 = rel;
					temp = m;
				//System.out.println(max);
				}
			}
			
			B[i][b]= max1;
			M[i][b]= temp;
			return max1;
		}

		else
		{
			double max2 = 0;
			double temp2 =0;
			double n =  Math.floor(b/c[i]);
			//System.out.println(n);
			for(int m = 1; m <= n; m++){
				double rel = reliability(b-(m*c[i]),r,c,i-1)*(1-Math.pow((1-r[i]), m));
				//System.out.println(rel);
				if (max2 < rel){
					max2 = rel;
					temp2 = m;
				}
			}
		
		B[i][b]= max2;
		M[i][b]=temp2;
		return max2;
		}
	}

	void printCost(int n, int b, int c[]){
		for(int i = n-1; i >= 0; i--){
			System.out.println(M[i][b] + " copies of machine " + (i+1) + " of cost " + c[i]);
			b = (int)(b-M[i][b]*c[i]);		 
		}
	}

	public static void main(String[] args){

		Reliability obj = new Reliability();

		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the total budget: ");
		int b = scan.nextInt();
		System.out.println("Enter number of machines: ");
		int n = scan.nextInt();
		System.out.println("Enter the Costs and Reliabilities of each machine (c1 r1 c2 r2 ...): ");
		double[][] data = new double[n][2];   
		for(int row = 0; row< n; row++){
			for(int col = 0;col< 2; col++){
				data[row][col] = scan.nextDouble();
			}
		}

		double r[] = new double[n];
		int c[] = new int[n];
		for (int i=0;i<=data.length-1;i++){
			r[i] = data[i][1];
		}
		for (int i=0;i<=data.length-1;i++){
			c[i] = (int)(data[i][0]);
		}

		for(int i = 0; i <= n-1; i++)
			for(int j = 0; j <= b; j++ )
				B[i][j] = -1;

		System.out.println("\nMaximum reliability of system: " + obj.reliability(b, r, c, n-1));
		obj.printCost(n, b, c);
		
		}	 
}