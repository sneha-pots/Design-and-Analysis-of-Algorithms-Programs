#include <stdio.h>

int matrix[10][10];
int visited[10], n, cost = 0;

void input()
{
	int i, j;

	printf("Enter the number of cities: ");
	scanf("%d", &n);

	printf("\nEnter the cost matrix row by row. Seperate the elements by spaces.\n\n");

	for (i = 0; i < n; i++)
	{
		printf("Enter elements of row %d:", i + 1);

		for (j = 0; j < n; j++)
		{
			scanf("%d", &matrix[i][j]);
		}
		printf("\n");
		visited[i] = 0;
	}

	printf("\nYour cost matrix is:");

	for (i = 0; i < n; i++)
	{
		printf("\n");

		for (j = 0; j < n; j++)
			printf("%d\t", matrix[i][j]);
	}
	printf("\n");
}

int least(int c)
{
	int i, nc = 999;
	int min = 999, kmin;

	for (i = 0; i < n; i++)
	{
		if ((matrix[c][i] != 0) && (visited[i] == 0))
			if (matrix[c][i] + matrix[i][c] < min)
			{
				min = matrix[i][c] + matrix[c][i];
				kmin = matrix[c][i];
				nc = i;
			}
	}

	if (min != 999)
		cost += kmin;

	return nc;
}

void mincost(int city)
{
	int i, ncity;

	visited[city] = 1;

	printf("%d--->", city + 1);
	ncity = least(city);

	if (ncity == 999)
	{
		ncity = 0;
		printf("%d", ncity + 1);
		cost += matrix[city][ncity];

		return;
	}

	mincost(ncity);
}

int main()
{
	input();

	printf("\nYour shortest path is: ");
	mincost(0); //passing 0 because starting vertex

	printf("\n\nMinimum cost is %d.\n ", cost);

	return 0;
}