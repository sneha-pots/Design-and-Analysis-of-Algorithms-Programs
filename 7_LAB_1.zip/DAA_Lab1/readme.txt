DAA Lab Assignment 1

Description:
    This project consists of two programs to sort the given file of student records using two different sorting algorithms, Insertion Sort and Selection Sort.

program1.c
    To sort the records in ascending order based on one of three parameters - Roll number, Name or Group number - which is to be provided by the user via command line arguments. Output is written to the output1.txt file.

    First argument: 1 (for Selection sort) or 2 (for Insertion sort)
    Second argument: 1 (for roll number) or 2 (for name) or 3 (for group)
    Input sample: ./a.out 1 3

program2.c
    To sort the records in ascending order by comparing group number, then roll number, and finally, name. The algorithm to be used must be specified by the user. Output is written to the output2.txt file.
    
    First argument: 1 (for Selection sort) or 2 (for Insertion sort)
    Input sample: ./a.out 2

Note: Output may need to be reloaded to see changes.

Algorithm logic used:
- The data from the input file is stored in an array of structures.
- Insertion sort (ascending order):
    The first element of the array is considered sorted and iterate over the rest. During each iteration, 
    we compare the current element 'key' to the element on its left. If the key value is smaller than the 
    value on its left, we compare it to the element further left, and so on. Each time, we move the greater 
    elements to the right. When we reach an element that is smaller than key, we insert key right before 
    that in the space made by moving the elements. 

- Selection Sort:
    We iterate over the array of size n from index 0 to (n-1). The first unsorted element is set as the
    minimum. For the rest of the unsorted array, if any element is smaller than the current minimum element,
    it is set as the new minimum. It is then swapped with the first position in the unsorted array.

Built With:
C

Authors:
Sneha Potluri (19XJ1A0572)
Shagufta Anjum (19XJ1A0568)
Group 7
