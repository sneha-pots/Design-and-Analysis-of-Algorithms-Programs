#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

struct student
{
    char id[20];
    char name[50];
    int group;
};

void swap(struct student *x, struct student *y)
{
    struct student temp = *x;
    *x = *y;
    *y = temp;
}

void insertionSort(struct student arr[], int n, int opt)
{
    int i, j;
    struct student key;
    for (i = 1; i < n; i++)
    {
        key = arr[i];
        j = i - 1;

        if (opt == 1) //Sorting by roll number
        {
            while (j >= 0 && strcmp(arr[j].id, key.id) > 0)
            {
                arr[j + 1] = arr[j];
                j = j - 1;
            }
        }

        else if (opt == 2) //Sorting by name
        {
            while (j >= 0 && strcmp(arr[j].name, key.name) > 0)
            {
                arr[j + 1] = arr[j];
                j = j - 1;
            }
        }

        else if (opt == 3) //Sorting by group number
        {
            while (j >= 0 && arr[j].group > key.group)
            {
                arr[j + 1] = arr[j];
                j = j - 1;
            }
        }

        arr[j + 1] = key;
    }
}

void selectionSort(struct student arr[], int n, int opt)
{
    int i, j, min;
    for (i = 0; i < n - 1; i++)
    {
        min = i;
        for (j = i + 1; j < n; j++)
        {
            if (opt == 1)
            {
                if (strcmp(arr[j].id, arr[min].id) < 0)
                    min = j;
            }
            else if (opt == 2)
            {
                if (strcmp(arr[j].name, arr[min].name) < 0)
                    min = j;
            }
            else if (opt == 3)
            {
                if (arr[j].group < arr[min].group)
                    min = j;
            }
        }
        swap(&arr[min], &arr[i]);
    }
}

int main(int argc, char *argv[])
{

    if (argc == 3)
    {
        int algo = atoi(argv[1]); //Option for algorithm
        int opt = atoi(argv[2]);  //Option for sorting parameter

        if ((opt == 1 || opt == 2 || opt == 3) && (algo == 1 || algo == 2))
        {
            int total = 86;
            struct student slist[total];

            //Opening input file
            FILE *fp;
            fp = fopen("input_data.txt", "r");
            if (fp == NULL)
            {
                printf("Error opening file\n");
                return 1;
            }

            //Reading from input file
            int i = 0;
            while (fscanf(fp, "%s %s %i", slist[i].id, slist[i].name, &(slist[i].group)) != EOF)
            {
                i++;
            }

            //Running sort algorithm
            if (algo == 1)
                selectionSort(slist, total, opt);
            else if (algo == 2)
                insertionSort(slist, total, opt);

            //Opening output file
            fp = fopen("output1.txt", "w");
            if (fp == NULL)
            {
                printf("Error opening file\n");
                return 1;
            }

            //Writing to output file
            for (int j = 0; j < total; j++)
            {
                fprintf(fp, "%s %s %i\n", slist[j].id, slist[j].name, slist[j].group);
            }

            fclose(fp);
            return 0;
        }
        else
        {
            printf("\nInvalid input.");
            return 1;
        }
    }
    else
    {
        printf("\nInvalid input.");
        return 1;
    }
}
